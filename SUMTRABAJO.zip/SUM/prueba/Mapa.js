/* =====================================================================
   SUM — Sistema de Ubicación Metro
   Motor del viaje: tren lateral con inercia, estaciones, túneles,
   tablero en vivo, mapa que se dibuja, cursor-señal y torniquete.
   Las funciones de modales, formularios y validación son las originales.
   ===================================================================== */

/* ---------- Ajustes (cámbialos aquí) ---------- */
const CONFIG_VIAJE = {
    INERCIA: 4.6,          // suavizado del tren: menor = más "pesado", mayor = más pegado al scroll
    VENTANA_ESTACION: 0.16,// zona (fracción de pantalla) en la que el tren frena al acercarse a una estación
    IMAN_ESTACION: 0.55,   // 0 = sin imán · 1 = el tren se clava en la estación al llegar
    VEL_PARADA: 120,       // px/s por debajo de los cuales se abren las puertas
    VEL_PARTIDA: 260,      // px/s por encima de los cuales se cierran
    INCLINACION_MAX: 8,    // grados que se inclina el tren a toda velocidad
    VEL_CHISPAS: 1700,     // px/s para que salgan chispas
    VEL_CALMA: 3500,       // px/s sostenidos para que aparezca el aviso "mantenga la calma"
    PARALLAX: { lejos: 0.30, titulo: 0.16, cerca: 0 },   // desplazamiento del valle del hero
    ZONA_HORARIA: 'America/Bogota'
};

const REDUCIDO = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const $ = (id) => document.getElementById(id);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

/* Cada módulo se aísla: si uno falla, el resto (y el login) siguen funcionando */
function seguro(fn) {
    try { fn(); } catch (err) { console.error('[SUM] error en módulo:', fn.name, err); }
}

/* Funciones que se ejecutan en cada cuadro (un único requestAnimationFrame compartido) */
const TICKS = [];
let LISTO = false;   // true cuando el preloader terminó (las puertas del tren esperan a eso)

document.addEventListener('DOMContentLoaded', () => {
    if (window.lucide) lucide.createIcons();
    seguro(iniciarPreloader);
    seguro(construirEscena);
    seguro(configurarFranjaCielo);
    seguro(setupScrollReveal);
    seguro(setupLiveValidation);
    seguro(setupViaje);
    seguro(setupTuneles);
    seguro(setupHeroParallax);
    seguro(setupTablero);
    seguro(setupMapa);
    seguro(setupInclinacionCarteles);
    seguro(setupCursor);
    seguro(setupTeclado);
    seguro(arrancarBucle);
});

/* ---------- Hora de Medellín (admite ?hora=19:30&fecha=2026-10-11 para probar) ---------- */
function ahoraBogota() {
    const q = new URLSearchParams(location.search);
    const fmt = new Intl.DateTimeFormat('en-US', {
        timeZone: CONFIG_VIAJE.ZONA_HORARIA, year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', weekday: 'short', hourCycle: 'h23'
    });
    const o = {};
    fmt.formatToParts(new Date()).forEach(p => { o[p.type] = p.value; });
    let y = +o.year, m = +o.month, d = +o.day, hh = +o.hour % 24, mm = +o.minute;
    if (/^\d{4}-\d{2}-\d{2}$/.test(q.get('fecha') || '')) {
        [y, m, d] = q.get('fecha').split('-').map(Number);
    }
    if (/^\d{1,2}:\d{2}$/.test(q.get('hora') || '')) {
        [hh, mm] = q.get('hora').split(':').map(Number);
    }
    const dow = new Date(Date.UTC(y, m - 1, d)).getUTCDay();
    const iso = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    return { y, m, d, hh, mm, dow, iso };
}

/* ---------- Festivos de Colombia (Ley Emiliani + Semana Santa), calculados por año ---------- */
const _cacheFestivos = {};
function _pascua(y) {
    const a = y % 19, b = Math.floor(y / 100), c = y % 100, d = Math.floor(b / 4), e = b % 4;
    const f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30;
    const i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7;
    const m = Math.floor((a + 11 * h + 22 * l) / 451);
    const mes = Math.floor((h + l - 7 * m + 114) / 31), dia = ((h + l - 7 * m + 114) % 31) + 1;
    return Date.UTC(y, mes - 1, dia);
}
function _lunesSiguiente(ms) { return ms + ((8 - new Date(ms).getUTCDay()) % 7) * 864e5; }
function festivosColombia(y) {
    if (_cacheFestivos[y]) return _cacheFestivos[y];
    const set = new Set(), iso = ms => new Date(ms).toISOString().slice(0, 10);
    [[0, 1], [4, 1], [6, 20], [7, 7], [11, 8], [11, 25]].forEach(([m, d]) => set.add(iso(Date.UTC(y, m, d))));
    [[0, 6], [2, 19], [5, 29], [7, 15], [9, 12], [10, 1], [10, 11]].forEach(([m, d]) => set.add(iso(_lunesSiguiente(Date.UTC(y, m, d)))));
    const p = _pascua(y);
    [-3, -2].forEach(o => set.add(iso(p + o * 864e5)));
    [43, 64, 71].forEach(o => set.add(iso(_lunesSiguiente(p + o * 864e5))));
    return (_cacheFestivos[y] = set);
}
function esFestivo(iso) { return festivosColombia(+iso.slice(0, 4)).has(iso); }


/* ---------- Menú Móvil ---------- */
function toggleMenu() {
    const menu = document.getElementById('mobileMenu');
    const toggle = document.getElementById('menuToggle');
    menu.classList.toggle('active');
    toggle.classList.toggle('active');
    toggle.setAttribute('aria-expanded', menu.classList.contains('active'));
    document.body.style.overflow = menu.classList.contains('active') ? 'hidden' : '';
}

/* ---------- Mostrar/Ocultar contraseña ---------- */
function togglePassword(inputId, btn) {
    const input = document.getElementById(inputId);
    const mostrando = input.type === 'text';

    input.type = mostrando ? 'password' : 'text';
    btn.innerHTML = `<i data-lucide="${mostrando ? 'eye' : 'eye-off'}"></i>`;
    btn.setAttribute('aria-label', mostrando ? 'Mostrar contraseña' : 'Ocultar contraseña');

    if (window.lucide) lucide.createIcons();
}

/* ---------- Modales ---------- */
function abrirRecuperar() {
    cerrarLogin();
    document.getElementById('forgotModal').classList.add('active');
}
function cerrarRecuperar() {
    document.getElementById('forgotModal').classList.remove('active');
    document.getElementById('forgotSuccess').classList.remove('active');
    document.getElementById('forgotForm').reset();
}
function recuperarPassword(event) {
    event.preventDefault();
    const successEl = document.getElementById('forgotSuccess');
    successEl.classList.add('active');
}
function abrirLogin() {
    cerrarRegistro();
    cerrarRecuperar();
    document.getElementById('loginModal').classList.add('active');
}
function cerrarLogin() {
    document.getElementById('loginModal').classList.remove('active');
    document.getElementById('loginError').classList.remove('active');
}
function abrirRegistro() {
    cerrarLogin();
    document.getElementById('registerModal').classList.add('active');
}
function cerrarRegistro() {
    document.getElementById('registerModal').classList.remove('active');
    document.getElementById('registerError').classList.remove('active');
    cerrarTodasLasInfo();
}

// Cerrar modal al hacer clic fuera del contenido
document.addEventListener('click', (e) => {
    if (e.target.classList && e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active');
    }
});

/* ---------- Ventanas emergentes con los parámetros de cada campo ---------- */
function cerrarTodasLasInfo() {
    document.querySelectorAll('.field-info.active').forEach(info => info.classList.remove('active'));
}

/* ---------- Validación de contraseña ---------- */
// Requisitos: más de 8 caracteres, 1 mayúscula, 1 minúscula, 1 número y 1 símbolo especial
const PASSWORD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{9,}$/;

/* ---------- Validación de nombre completo ---------- */
// Solo letras (incluye tildes y ñ) y espacios; sin números ni caracteres especiales
const NOMBRE_REGEX = /^[A-Za-zÀ-ÿ\u00f1\u00d1\s]+$/;

function validarNombre(nombre) {
    if (!nombre.trim()) {
        return "El nombre completo es obligatorio.";
    }
    if (!NOMBRE_REGEX.test(nombre)) {
        return "El nombre completo solo puede contener letras y espacios.";
    }
    return null; // válido
}

/* ---------- Validación de nombre de usuario ---------- */
// Solo letras y números, sin espacios ni caracteres especiales
const USERNAME_REGEX = /^[A-Za-z0-9]+$/;

function validarUsuario(usuario) {
    if (!usuario.trim()) {
        return "El nombre de usuario es obligatorio.";
    }
    if (/\s/.test(usuario)) {
        return "El nombre de usuario no puede contener espacios.";
    }
    if (!USERNAME_REGEX.test(usuario)) {
        return "El nombre de usuario solo puede contener letras y números, sin caracteres especiales.";
    }
    return null; // válido
}

function validarPassword(password) {
    if (password.length <= 8) {
        return "La contraseña debe tener más de 8 caracteres.";
    }
    if (!/[A-Z]/.test(password)) {
        return "La contraseña debe incluir al menos una letra mayúscula.";
    }
    if (!/[a-z]/.test(password)) {
        return "La contraseña debe incluir al menos una letra minúscula.";
    }
    if (!/\d/.test(password)) {
        return "La contraseña debe incluir al menos un número.";
    }
    if (!/[^A-Za-z0-9]/.test(password)) {
        return "La contraseña debe incluir al menos un símbolo especial (ej. !@#$%).";
    }
    return null; // válida
}

/* ---------- Validación de correo (para el checklist en vivo) ---------- */
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/* ---------- Checklist en vivo: se corrige mientras el usuario escribe ---------- */
function actualizarChecklist(infoId, valor, evaluador) {
    const contenedor = document.getElementById(infoId);
    if (!contenedor) return;
    const resultados = evaluador(valor);

    contenedor.querySelectorAll('li[data-rule]').forEach(li => {
        const regla = li.getAttribute('data-rule');
        li.classList.remove('valid', 'invalid');
        if (valor.length === 0) return; // campo vacío: estado neutro (○)
        li.classList.add(resultados[regla] ? 'valid' : 'invalid');
    });
}

function evaluarNombre(v) {
    return { soloLetras: NOMBRE_REGEX.test(v) };
}
function evaluarUsuario(v) {
    return {
        sinEspacios: !/\s/.test(v),
        soloAlfanum: USERNAME_REGEX.test(v)
    };
}
function evaluarCorreo(v) {
    return { formatoCorreo: EMAIL_REGEX.test(v) };
}
function evaluarPassword(v) {
    return {
        longitud: v.length > 8,
        mayuscula: /[A-Z]/.test(v),
        minuscula: /[a-z]/.test(v),
        numero: /\d/.test(v),
        simbolo: /[^A-Za-z0-9]/.test(v)
    };
}
function evaluarConfirmPassword(v) {
    const original = document.getElementById('regPassword').value;
    return { coincide: v.length > 0 && v === original };
}

// Abre el checklist del campo al enfocarlo y lo cierra 20s después de salir de él
function enlazarAperturaEnFoco(inputId, infoId) {
    const input = document.getElementById(inputId);
    const info = document.getElementById(infoId);
    if (!input || !info) return;

    let temporizadorCierre = null;

    input.addEventListener('focus', () => {
        if (temporizadorCierre) clearTimeout(temporizadorCierre);
        cerrarTodasLasInfo();
        info.classList.add('active');
    });

    input.addEventListener('blur', () => {
        temporizadorCierre = setTimeout(() => {
            info.classList.remove('active');
        }, 20000); // 20 segundos de espera antes de ocultar el mensaje
    });
}

function setupLiveValidation() {
    const regNombre = document.getElementById('regNombre');
    const regUsername = document.getElementById('regUsername');
    const regEmail = document.getElementById('regEmail');
    const regPassword = document.getElementById('regPassword');
    const regConfirmPassword = document.getElementById('regConfirmPassword');

    if (!regNombre) return; // el formulario de registro no está en esta página

    regNombre.addEventListener('input', e => actualizarChecklist('infoNombre', e.target.value, evaluarNombre));
    regUsername.addEventListener('input', e => actualizarChecklist('infoUsuario', e.target.value, evaluarUsuario));
    regEmail.addEventListener('input', e => actualizarChecklist('infoCorreo', e.target.value, evaluarCorreo));

    regPassword.addEventListener('input', e => {
        actualizarChecklist('infoPassword', e.target.value, evaluarPassword);
        // Si ya se escribió la confirmación, revalidarla también al cambiar la contraseña
        if (regConfirmPassword.value.length > 0) {
            actualizarChecklist('infoConfirmPassword', regConfirmPassword.value, evaluarConfirmPassword);
        }
    });

    regConfirmPassword.addEventListener('input', e => actualizarChecklist('infoConfirmPassword', e.target.value, evaluarConfirmPassword));

    enlazarAperturaEnFoco('regNombre', 'infoNombre');
    enlazarAperturaEnFoco('regUsername', 'infoUsuario');
    enlazarAperturaEnFoco('regEmail', 'infoCorreo');
    enlazarAperturaEnFoco('regPassword', 'infoPassword');
    enlazarAperturaEnFoco('regConfirmPassword', 'infoConfirmPassword');
}

/* ---------- Formularios (demo) ---------- */
async function iniciarSesion(event) {
    event.preventDefault();
    const usuario = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
    const errorEl = document.getElementById('loginError');

    try {
        const res = await fetch('../PHP/login.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ usuario, password })
        });
        const data = await res.json();

        if (!data.exito) {
            errorEl.textContent = data.mensaje;
            errorEl.classList.add('active');
            return;
        }
        errorEl.classList.remove('active');
        cerrarLogin();
        window.location.href = "../MAPA/mapa.html";
    } catch (err) {
        errorEl.textContent = "Error de conexión con el servidor.";
        errorEl.classList.add('active');
    }
}

async function registrarUsuario(event) {
    event.preventDefault();
    const nombre = document.getElementById('regNombre').value;
    const usuario = document.getElementById('regUsername').value;
    const email = document.getElementById('regEmail').value;
    const password = document.getElementById('regPassword').value;
    const confirmPassword = document.getElementById('regConfirmPassword').value;
    const errorEl = document.getElementById('registerError');

    // Validación del nombre completo (solo letras y espacios)
    const errorNombre = validarNombre(nombre);
    if (errorNombre) {
        errorEl.textContent = errorNombre;
        errorEl.classList.add('active');
        return;
    }

    // Validación del nombre de usuario (sin espacios ni caracteres especiales)
    const errorUsuario = validarUsuario(usuario);
    if (errorUsuario) {
        errorEl.textContent = errorUsuario;
        errorEl.classList.add('active');
        return;
    }

    // Validación de coincidencia de contraseñas
    if (password !== confirmPassword) {
        errorEl.textContent = "Las contraseñas no coinciden.";
        errorEl.classList.add('active');
        return;
    }

    // Validación de requisitos de la contraseña (más de 8 caracteres, mayúscula, minúscula, número y símbolo)
    const errorValidacion = validarPassword(password);
    if (errorValidacion) {
        errorEl.textContent = errorValidacion;
        errorEl.classList.add('active');
        return;
    }

    try {
        const res = await fetch('../PHP/registro.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nombre, usuario, email, password, confirmPassword })
        });
        const data = await res.json();

        if (!data.exito) {
            errorEl.textContent = data.mensaje;
            errorEl.classList.add('active');
            return;
        }
        errorEl.classList.remove('active');
        cerrarRegistro();
        window.location.href = "../MAPA/mapa.html";
    } catch (err) {
        errorEl.textContent = "Error de conexión con el servidor.";
        errorEl.classList.add('active');
    }
}


/* =====================================================================
   PRELOADER — puertas del metro
   ===================================================================== */
function iniciarPreloader() {
    const pre = $('preloader');
    if (!pre || REDUCIDO) {
        if (pre) pre.classList.add('fin');
        LISTO = true;
        return;
    }
    document.documentElement.classList.add('bloqueado');
    let abierto = false;
    const abrir = () => {
        if (abierto) return;
        abierto = true;
        pre.classList.add('abre');
        setTimeout(() => {
            pre.classList.add('fin');
            document.documentElement.classList.remove('bloqueado');
            LISTO = true;
        }, 1100);
    };
    const espera = new Promise(r => setTimeout(r, 1300));   // tres parpadeos del "pitido"
    const fuentes = (document.fonts && document.fonts.ready)
        ? Promise.race([document.fonts.ready, new Promise(r => setTimeout(r, 1800))])
        : Promise.resolve();
    Promise.all([espera, fuentes]).then(abrir);
    setTimeout(abrir, 3500);   // red de seguridad
}

/* =====================================================================
   ESCENA DEL HERO — estrellas, ciudad y cielo según la hora
   ===================================================================== */
function mulberry32(a) {
    return function () {
        a |= 0; a = a + 0x6D2B79F5 | 0;
        let t = Math.imul(a ^ a >>> 15, 1 | a);
        t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
}

function construirEscena() {
    const NS = 'http://www.w3.org/2000/svg';

    const cielo = $('estrellas');
    if (cielo) {
        const rnd = mulberry32(7), frag = document.createDocumentFragment();
        for (let i = 0; i < 70; i++) {
            const s = document.createElement('i');
            s.style.left = (rnd() * 100).toFixed(1) + '%';
            s.style.top = (rnd() * 100).toFixed(1) + '%';
            s.style.opacity = (0.35 + rnd() * 0.65).toFixed(2);
            if (rnd() > 0.86) { s.style.width = s.style.height = '3px'; }
            frag.appendChild(s);
        }
        cielo.appendChild(frag);
    }

    // Edificios del valle: siluetas + una capa de ventanas encendidas (se ven al atardecer y de noche)
    const g = $('ciudad'), luces = $('lucesCiudad');
    if (!g || !luces) return;
    const rnd = mulberry32(21);
    let x = -10;
    while (x < 1610) {
        const w = 14 + rnd() * 26;
        const alto = 26 + rnd() * 50 + Math.abs(Math.sin(x / 230)) * 74;
        const y = 700 - alto;
        [[g, null], [luces, 'url(#patVentanas)']].forEach(([grupo, relleno]) => {
            const r = document.createElementNS(NS, 'rect');
            r.setAttribute('x', x.toFixed(1)); r.setAttribute('y', y.toFixed(1));
            r.setAttribute('width', w.toFixed(1)); r.setAttribute('height', (alto + 60).toFixed(1));
            if (relleno) { r.setAttribute('fill', relleno); r.setAttribute('opacity', (0.3 + rnd() * 0.7).toFixed(2)); }
            grupo.appendChild(r);
        });
        x += w + rnd() * 3;
    }
}

function configurarFranjaCielo() {
    const hero = $('hero');
    if (!hero) return;
    const nombres = { amanecer: 'amanecer', dia: 'día', atardecer: 'atardecer', noche: 'noche' };
    const aplicar = () => {
        const n = ahoraBogota(), h = n.hh + n.mm / 60;
        let franja = 'noche';
        if (h >= 5 && h < 7) franja = 'amanecer';
        else if (h >= 7 && h < 17) franja = 'dia';
        else if (h >= 17 && h < 19) franja = 'atardecer';
        hero.dataset.franja = franja;

        // Sol de 6 a 18 h, luna el resto: cruza el cielo en arco
        const t = (h >= 6 && h < 18) ? (h - 6) / 12 : ((h - 18 + 24) % 24) / 12;
        hero.style.setProperty('--astro-x', (10 + t * 80).toFixed(1) + '%');
        hero.style.setProperty('--astro-y', (72 - Math.sin(Math.PI * t) * 52).toFixed(1) + '%');

        const hora = $('heroHora');
        if (hora) {
            const txt = new Intl.DateTimeFormat('es-CO', { hour: 'numeric', minute: '2-digit', hour12: true, timeZone: 'UTC' })
                .format(new Date(Date.UTC(2000, 0, 1, n.hh, n.mm)));
            hora.textContent = `Medellín · ${txt} · ${nombres[franja]}`;
        }
    };
    aplicar();
    setInterval(aplicar, 30000);
}

/* =====================================================================
   REVELADO — el contenido "baja del tren"
   ===================================================================== */
function setupScrollReveal() {
    const els = [...document.querySelectorAll('.baja')];
    const cuenta = new Map();
    els.forEach(el => {                      // escalonado por grupo de hermanos
        const p = el.parentElement, n = cuenta.get(p) || 0;
        el.style.setProperty('--i', n);
        cuenta.set(p, n + 1);
    });
    if (REDUCIDO || !('IntersectionObserver' in window)) {
        els.forEach(el => el.classList.add('visible'));
        return;
    }
    // Los títulos gigantes se recortan con clip-path (quedan con área 0), así que
    // el observador vigila a su contenedor y desde ahí los descubre.
    const grupos = new Map();
    els.forEach(el => {
        const objetivo = el.matches('.titulo-xl, .terminal-titulo') ? el.parentElement : el;
        if (!grupos.has(objetivo)) grupos.set(objetivo, []);
        grupos.get(objetivo).push(el);
    });
    const obs = new IntersectionObserver((entradas) => {
        entradas.forEach(e => {
            if (!e.isIntersecting) return;
            grupos.get(e.target).forEach(el => el.classList.add('visible'));
            obs.unobserve(e.target);
        });
    }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
    grupos.forEach((_, objetivo) => obs.observe(objetivo));
}

/* =====================================================================
   EL VIAJE — andén lateral, tren, estaciones y megafonía
   ===================================================================== */
function setupViaje() {
    const riel = $('riel'), tren = $('tren'), trenSvg = $('trenSvg');
    const estela = $('rielEstela'), contEst = $('rielEstaciones');
    const navProg = $('navProgress'), navTren = $('navTrain');
    const nav = document.querySelector('.metro-nav:not(.metro-nav-vertical)');
    const megaTexto = $('megaTexto'), megaPlaca = $('megaPlaca'), megaCont = $('megaContador');
    const vagon = $('vagonLuces');
    if (!riel || !tren) return;

    const defs = [
        { id: 'hero',       letra: 'S', nombre: 'Inicio',        lc: '#F4F5F0',          msg: 'Estás en el origen. Próxima estación: Beneficios.' },
        { id: 'beneficios', letra: 'A', nombre: 'Beneficios',    lc: 'var(--linea-a)',   msg: 'Estación A, Beneficios. Próxima estación: Cultura Metro.' },
        { id: 'cultura',    letra: 'B', nombre: 'Cultura Metro', lc: 'var(--linea-b)',   msg: 'Estación B, Cultura Metro. Próxima estación: Horarios.' },
        { id: 'horarios',   letra: 'K', nombre: 'Horarios',      lc: 'var(--linea-k)',   msg: 'Estación K, Horarios. Próxima estación: Contacto.' },
        { id: 'Contacto',   letra: 'M', nombre: 'Contacto',      lc: 'var(--linea-m)',   msg: 'Fin de línea. Gracias por viajar con SUM.' }
    ];
    const ultima = defs.length - 1;

    // Estaciones sobre el riel
    const est = defs.map((d, i) => {
        const a = document.createElement('a');
        a.className = 'riel-estacion';
        a.href = '#' + d.id;
        a.tabIndex = -1;
        a.style.setProperty('--lc', d.lc);
        a.innerHTML = `<span class="est-dot">${d.letra}</span><span class="est-bandera">${d.nombre}</span>`;
        contEst.appendChild(a);
        return { el: a, def: d, stop: 0, ini: 0, y: 0 };
    });
    if (vagon) [...vagon.children].forEach((l, i) => { l.style.transitionDelay = (i * 150) + 'ms'; });

    // Medidas
    let vh = 0, maxScroll = 1, railH = 0, trenH = 0, margen = 0, navW = 0, hh = 0;
    const yDe = (sc) => margen + (sc / maxScroll) * (railH - 2 * margen);
    function medir() {
        vh = window.innerHeight;
        hh = document.querySelector('.header').offsetHeight;
        maxScroll = Math.max(1, document.documentElement.scrollHeight - vh);
        railH = riel.clientHeight;
        trenH = tren.offsetHeight;
        margen = trenH / 2 + 6;
        navW = nav ? nav.clientWidth : 0;
        est.forEach((e, i) => {
            const sec = document.getElementById(e.def.id);
            const top = sec.getBoundingClientRect().top + window.scrollY;
            e.ini = i === 0 ? 0 : top - hh - 6;
            e.stop = clamp(i === 0 ? 0 : (i === ultima ? maxScroll : e.ini), 0, maxScroll);
            e.y = yDe(e.stop);
            e.el.style.top = e.y.toFixed(1) + 'px';
        });
        prev.y = null;   // fuerza reescritura
    }

    // Estado
    let sc = window.scrollY, prevEf = sc, vS = 0, ultimo = 0;
    let activo = -1, llegada = -1, dirActual = 'abajo', velAlta = false, rapido = 0, proximoAviso = 0;
    const prev = { y: null, est: 0, incl: 0 };

    const navStops = [...document.querySelectorAll('.metro-stop')];
    function marcarActivo(i) {
        activo = i;
        est.forEach((e, k) => e.el.classList.toggle('activa', k === i));
        const id = defs[i].id;
        navStops.forEach(s => s.classList.toggle('active', (s.getAttribute('href') || '').replace('#', '') === id));
        if (megaTexto) {
            megaTexto.textContent = defs[i].msg;
            megaTexto.classList.remove('entra'); void megaTexto.offsetWidth; megaTexto.classList.add('entra');
        }
        if (megaPlaca) { megaPlaca.textContent = defs[i].letra; megaPlaca.style.setProperty('--lc', defs[i].lc); }
        if (megaCont) megaCont.textContent = `${i + 1} / ${defs.length}`;
    }

    function llegar(i) {
        llegada = i;
        tren.dataset.puertas = 'abiertas';
        const e = est[i];
        e.el.classList.remove('llegada'); void e.el.offsetWidth; e.el.classList.add('llegada');
        // Pasajeros que bajan del tren
        if (!REDUCIDO) {
            for (let k = 0; k < 5; k++) {
                const p = document.createElement('span');
                p.className = 'pasajero';
                p.style.top = (prev.y + (k - 2) * 7) + 'px';
                p.style.setProperty('--px', (26 + Math.random() * 16).toFixed(0) + 'px');
                p.style.setProperty('--py', ((Math.random() - 0.5) * 16).toFixed(0) + 'px');
                p.style.animationDelay = (k * 110) + 'ms';
                riel.appendChild(p);
                setTimeout(() => p.remove(), 1900);
            }
        }
        if (i === ultima) {               // terminal: se apagan las luces del vagón una por una
            tren.classList.add('apagado');
            if (vagon) vagon.classList.add('apagado');
        }
    }
    function partir() {
        const i = llegada;
        llegada = -1;
        tren.dataset.puertas = 'cerradas';
        if (i >= 0) est[i].el.classList.remove('llegada');
        if (i === ultima) {
            tren.classList.remove('apagado');
            if (vagon) vagon.classList.remove('apagado');
        }
    }

    function mostrarAviso() {
        const a = $('avisoCalma');
        if (!a) return;
        a.classList.add('activo');
        setTimeout(() => a.classList.remove('activo'), 3400);
    }

    TICKS.push((t, dt) => {
        const objetivo = window.scrollY;
        if (REDUCIDO) sc = objetivo;
        else sc += (objetivo - sc) * (1 - Math.exp(-CONFIG_VIAJE.INERCIA * dt));
        if (Math.abs(objetivo - sc) < 0.05) sc = objetivo;
        window.__scSuave = sc;

        // Estación más cercana e imán: el tren "se acomoda" al llegar
        let cerca = 0, dmin = Infinity;
        est.forEach((e, i) => { const d = Math.abs(sc - e.stop); if (d < dmin) { dmin = d; cerca = i; } });
        const W = vh * CONFIG_VIAJE.VENTANA_ESTACION;
        let scEf = sc;
        if (!REDUCIDO && dmin < W) {
            scEf = sc + (est[cerca].stop - sc) * CONFIG_VIAJE.IMAN_ESTACION * Math.pow(1 - dmin / W, 2);
        }

        // Velocidad (px/s) suavizada: gobierna inclinación, estiramiento, chispas y puertas
        const v = (scEf - prevEf) / dt;
        prevEf = scEf;
        vS += (v - vS) * Math.min(1, dt * 10);
        const av = Math.abs(vS);

        // Posición del tren, estela y riel superior
        const p = clamp(scEf / maxScroll, 0, 1);
        const y = yDe(scEf);
        if (y !== prev.y) {
            tren.style.transform = `translate3d(0,${(y - trenH / 2).toFixed(2)}px,0)`;
            estela.style.transform = `scaleY(${clamp(y / railH, 0, 1).toFixed(4)})`;
            if (navProg) navProg.style.transform = `translateY(-50%) scaleX(${p.toFixed(4)})`;
            if (navTren && navW) navTren.style.transform = `translate3d(${(4 + p * (navW - 8) - 17).toFixed(2)}px,-50%,0)`;
            prev.y = y;
        }

        // Detalles de velocidad: ventanas que se estiran e inclinación
        const estir = 1 + Math.min(1.2, av / 1800);
        if (Math.abs(estir - prev.est) > 0.02) { trenSvg.style.setProperty('--est', estir.toFixed(2)); prev.est = estir; }
        const incl = REDUCIDO ? 0 : clamp(vS / 260, -CONFIG_VIAJE.INCLINACION_MAX, CONFIG_VIAJE.INCLINACION_MAX);
        if (Math.abs(incl - prev.incl) > 0.05) { trenSvg.style.transform = `rotate(${incl.toFixed(2)}deg)`; prev.incl = incl; }
        if (av > 90) {
            const d = vS > 0 ? 'abajo' : 'arriba';
            if (d !== dirActual) { dirActual = d; tren.dataset.dir = d; }
        }
        const alta = av > CONFIG_VIAJE.VEL_CHISPAS;
        if (alta !== velAlta) { velAlta = alta; tren.dataset.vel = alta ? 'alta' : 'baja'; }

        // Llegada y partida (con histéresis para que las puertas no titilen)
        if (LISTO) {
            const enVentana = dmin < W * 0.55;
            if (llegada === -1 && enVentana && av < CONFIG_VIAJE.VEL_PARADA) llegar(cerca);
            else if (llegada !== -1 && (av > CONFIG_VIAJE.VEL_PARTIDA || !enVentana || cerca !== llegada)) partir();
        }

        // Estación activa (para el nav, el riel y la megafonía)
        let a = 0;
        est.forEach((e, i) => { if (e.ini <= window.scrollY + vh * 0.45) a = i; });
        if (window.scrollY >= maxScroll - 4) a = ultima;
        if (a !== activo) marcarActivo(a);

        // Easter egg: scroll a toda velocidad
        if (av > CONFIG_VIAJE.VEL_CALMA) {
            rapido += dt;
            if (rapido > 0.5 && t > proximoAviso && !REDUCIDO) { mostrarAviso(); proximoAviso = t + 25000; }
        } else rapido = Math.max(0, rapido - dt * 2);
    });

    // Remedir cuando cambie el layout
    let pendiente = false;
    const remedir = () => { if (pendiente) return; pendiente = true; requestAnimationFrame(() => { pendiente = false; medir(); }); };
    window.addEventListener('resize', remedir);
    window.addEventListener('load', remedir);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(remedir);
    if ('ResizeObserver' in window) new ResizeObserver(remedir).observe(document.body);
    medir();
    marcarActivo(0);
}

/* =====================================================================
   TÚNELES — aros de luz que vuelan hacia ti
   ===================================================================== */
function setupTuneles() {
    const tuneles = [...document.querySelectorAll('.tunel')].map(el => ({ el, aros: [...el.querySelectorAll('.tunel-aros i')], vis: false }));
    if (!tuneles.length || REDUCIDO) return;
    const obs = new IntersectionObserver(es => es.forEach(e => {
        const t = tuneles.find(x => x.el === e.target); if (t) t.vis = e.isIntersecting;
    }), { rootMargin: '10% 0px' });
    tuneles.forEach(t => obs.observe(t.el));

    TICKS.push(() => {
        const vh = window.innerHeight;
        tuneles.forEach(t => {
            if (!t.vis) return;
            const r = t.el.getBoundingClientRect();
            const p = clamp((vh - r.top) / (vh + r.height), 0, 1);
            const n = t.aros.length;
            t.aros.forEach((a, k) => {
                const fase = (p * 2.4 + k / n) % 1;
                const s = 0.05 + Math.pow(fase, 2.2) * 1.9;
                a.style.transform = `scale(${s.toFixed(3)})`;
                a.style.opacity = (Math.sin(Math.PI * fase) * 0.95).toFixed(3);
            });
        });
    });
}

/* =====================================================================
   HERO — parallax del valle
   ===================================================================== */
function setupHeroParallax() {
    const hero = $('hero');
    if (!hero || REDUCIDO) return;
    const capas = [...hero.querySelectorAll('[data-par]')].map(el => ({ el, f: CONFIG_VIAJE.PARALLAX[el.dataset.par] || 0, last: null }));
    let vis = true;
    new IntersectionObserver(es => { vis = es[0].isIntersecting; }).observe(hero);
    TICKS.push(() => {
        if (!vis) return;
        const sc = window.__scSuave || 0;
        capas.forEach(c => {
            if (!c.f) return;
            const y = +(sc * c.f).toFixed(1);
            if (y !== c.last) { c.el.style.transform = `translate3d(0,${y}px,0)`; c.last = y; }
        });
    });
}


/* =====================================================================
   TABLERO DE HORARIOS — split-flap + LED de 7 segmentos, en vivo
   Los datos salen de la tabla (data-dias, data-inicio, data-fin)
   ===================================================================== */
const SEGMENTOS = { '0': 'abcdef', '1': 'bc', '2': 'abdeg', '3': 'abcdg', '4': 'bcfg', '5': 'acdfg', '6': 'acdefg', '7': 'abc', '8': 'abcdefg', '9': 'abcdfg', '-': 'g', ' ': '' };

function ledHTML(texto) {
    return [...texto].map(c => {
        if (c === ':') return '<span class="dp"><i></i><i></i></span>';
        const on = SEGMENTOS[c] || '';
        return '<span class="d">' + 'abcdefg'.split('').map(s =>
            `<i class="${'adg'.includes(s) ? 'h' : 'v'} ${s}${on.includes(s) ? ' on' : ''}"></i>`).join('') + '</span>';
    }).join('');
}
function ledPoner(el, texto) {
    if (!el || el.dataset.t === texto) return;
    el.dataset.t = texto;
    el.innerHTML = ledHTML(texto);
}
const aHHMM = (min) => `${String(Math.floor(min / 60)).padStart(2, '0')}:${String(min % 60).padStart(2, '0')}`;
const aMin = (hhmm) => { const [h, m] = hhmm.split(':').map(Number); return h * 60 + m; };

/* Celdas de tablero de salidas: cada carácter gira antes de asentarse */
class Flap {
    constructor(el, n) {
        this.n = n; this.actual = ' '.repeat(n); this.cells = [];
        for (let i = 0; i < n; i++) {
            const c = document.createElement('span');
            c.className = 'fl'; c.textContent = ' ';
            el.appendChild(c); this.cells.push(c);
        }
    }
    poner(texto) {
        const t = texto.toUpperCase().padEnd(this.n).slice(0, this.n);
        for (let i = 0; i < this.n; i++) if (t[i] !== this.actual[i]) this._cambiar(i, t[i]);
        this.actual = t;
    }
    _golpe(c) { c.classList.remove('cambio'); void c.offsetWidth; c.classList.add('cambio'); }
    _cambiar(i, ch) {
        const c = this.cells[i];
        if (REDUCIDO) { c.textContent = ch; return; }
        const ALFA = 'ABCDEFGHIJKLMNÑOPQRSTUVWXYZ0123456789:';
        let k = 0; const pasos = 3 + (i % 4);
        const paso = () => {
            if (k < pasos) { c.textContent = ALFA[Math.floor(Math.random() * ALFA.length)]; this._golpe(c); k++; setTimeout(paso, 55); }
            else { c.textContent = ch; this._golpe(c); }
        };
        setTimeout(paso, i * 32);
    }
}

function setupTablero() {
    const tablero = $('tablero'), tabla = $('tablaHorarios');
    if (!tablero || !tabla) return;
    const ledReloj = $('ledReloj'), ledLineas = $('ledLineas'), ledHoras = $('ledHoras');
    const cont = $('tabFilas'), diaEl = $('tabDia'), sr = $('tabSr');

    const HOR = [...tabla.querySelectorAll('tbody tr')].map(tr => ({
        tr, dias: tr.dataset.dias, ini: aMin(tr.dataset.inicio), fin: aMin(tr.dataset.fin),
        lineas: tr.querySelector('.line-tags').textContent.trim().split(/\s+/)
    }));
    const NOMBRE_TIPO = { 'lun-sab': 'Lunes a sábados', 'dom-fes': 'Domingos y festivos' };
    const tipoDe = (iso, dow) => (dow === 0 || esFestivo(iso)) ? 'dom-fes' : 'lun-sab';

    let visible = false, tipoPintado = null, filas = [], textoSr = '', primera = true;

    function evaluar() {
        const n = ahoraBogota(), m = n.hh * 60 + n.mm;
        const tipo = tipoDe(n.iso, n.dow);
        const sig = new Date(Date.UTC(n.y, n.m - 1, n.d + 1));
        const isoSig = sig.toISOString().slice(0, 10);
        const tipoSig = tipoDe(isoSig, sig.getUTCDay());

        const grupos = HOR.filter(g => g.dias === tipo).map(g => {
            let estado, proximo;
            if (m < g.ini) { estado = 'antes'; proximo = 'ABRE ' + aHHMM(g.ini); }
            else if (m < g.fin) { estado = 'abierto'; proximo = 'CIERRA ' + aHHMM(g.fin); }
            else {
                estado = 'cerrado';
                const gm = HOR.find(x => x.dias === tipoSig && x.lineas.includes(g.lineas[0]));
                proximo = gm ? 'ABRE MAÑANA ' + aHHMM(gm.ini) : 'ABRE MAÑANA';
            }
            return { g, estado, proximo };
        });
        HOR.forEach(g => g.tr.classList.toggle('en-servicio', g.dias === tipo && grupos.find(x => x.g === g).estado === 'abierto'));

        const abiertas = new Set();
        grupos.forEach(x => { if (x.estado === 'abierto') x.g.lineas.forEach(l => abiertas.add(l)); });
        return { n, m, tipo, grupos, nAbiertas: abiertas.size, horas: grupos[0] ? grupos[0].g.fin - grupos[0].g.ini : 0 };
    }

    function construirFilas(ev) {
        cont.innerHTML = '';
        filas = ev.grupos.map(x => {
            const f = document.createElement('div');
            f.className = 'fila';
            f.innerHTML = '<div class="fila-lineas"></div><div class="fl-grupo fl-estado" aria-hidden="true"></div><div class="fl-grupo fl-proximo" aria-hidden="true"></div>';
            x.g.lineas.forEach(l => {
                const c = document.createElement('span');
                c.className = 'chip-linea'; c.dataset.l = l; c.textContent = l;
                f.firstChild.appendChild(c);
            });
            cont.appendChild(f);
            return { el: f, estado: new Flap(f.querySelector('.fl-estado'), 11), proximo: new Flap(f.querySelector('.fl-proximo'), 17) };
        });
        tipoPintado = ev.tipo;
    }

    const TXT_ESTADO = { abierto: 'EN SERVICIO', antes: 'POR ABRIR', cerrado: 'CERRADO' };

    function pintar() {
        const ev = evaluar();
        const hhmm = aHHMM(ev.m);
        const diasSem = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
        const festivo = esFestivo(ev.n.iso) && ev.n.dow !== 0;
        diaEl.textContent = `${festivo ? 'Festivo' : diasSem[ev.n.dow]} · ${NOMBRE_TIPO[ev.tipo]}`;
        if (!visible) return;
        ledPoner(ledReloj, hhmm);
        if (tipoPintado !== ev.tipo) construirFilas(ev);
        ev.grupos.forEach((x, i) => {
            filas[i].el.dataset.estado = x.estado;
            filas[i].estado.poner(TXT_ESTADO[x.estado]);
            filas[i].proximo.poner(x.proximo);
        });
        if (primera) { primera = false; contarLed(ledLineas, ev.nAbiertas, v => String(v)); contarLed(ledHoras, ev.horas, aHHMM); }
        else { ledPoner(ledLineas, String(ev.nAbiertas)); ledPoner(ledHoras, aHHMM(ev.horas)); }

        const principal = ev.grupos[0];
        const t = `Ahora son las ${hhmm} en Medellín. ${ev.nAbiertas} líneas operando. ` +
            (principal ? `${TXT_ESTADO[principal.estado].toLowerCase()}, ${principal.proximo.toLowerCase()}.` : '');
        if (t !== textoSr) { textoSr = t; sr.textContent = t; }
    }

    /* Cuenta animada del display LED */
    function contarLed(el, destino, formato) {
        if (REDUCIDO || destino === 0) { ledPoner(el, formato(destino)); return; }
        const t0 = performance.now(), dur = 1100;
        const paso = (t) => {
            const k = clamp((t - t0) / dur, 0, 1), e = 1 - Math.pow(1 - k, 3);
            ledPoner(el, formato(Math.round(destino * e)));
            if (k < 1) requestAnimationFrame(paso);
        };
        requestAnimationFrame(paso);
    }

    // Primer vistazo: pinta y gira las celdas cuando el tablero entra en pantalla
    const ev0 = evaluar();
    ledPoner(ledReloj, '--:--'); ledPoner(ledLineas, '0'); ledPoner(ledHoras, '--:--');
    new IntersectionObserver((es, o) => {
        if (es[0].isIntersecting) { visible = true; pintar(); o.disconnect(); }
    }, { threshold: 0.25 }).observe(tablero);
    diaEl.textContent = '…';
    pintar();

    setInterval(pintar, 15000);
    setInterval(() => ledReloj && ledReloj.classList.toggle('pausa'), 1000);   // dos puntos del reloj
}

/* =====================================================================
   MAPA ESQUEMÁTICO — las líneas se dibujan con el scroll
   ===================================================================== */
function setupMapa() {
    const svg = $('mapaSvg');
    if (!svg) return;
    const lineas = [...svg.querySelectorAll('.mapa-linea')];
    const ests = [...svg.querySelectorAll('.mapa-est')];
    if (REDUCIDO) {
        lineas.forEach(l => { l.style.strokeDashoffset = 0; });
        ests.forEach(e => e.classList.add('on'));
        return;
    }
    let vis = false;
    new IntersectionObserver(es => { vis = es[0].isIntersecting; }, { rootMargin: '20% 0px' }).observe(svg);
    const ultimo = lineas.map(() => -1);

    TICKS.push(() => {
        if (!vis) return;
        const vh = window.innerHeight, r = svg.getBoundingClientRect();
        const p = clamp((vh * 0.9 - r.top) / (vh * 0.65), 0, 1);       // avance del bloque por la pantalla
        lineas.forEach((l, i) => {
            const lp = clamp((p - i * 0.14) / 0.56, 0, 1);              // cada línea arranca un poco después
            if (Math.abs(lp - ultimo[i]) > 0.002) {
                ultimo[i] = lp;
                l.style.strokeDashoffset = (1 - lp).toFixed(4);
                ests.forEach(e => {
                    if (e.dataset.linea === l.dataset.linea) e.classList.toggle('on', lp >= parseFloat(e.dataset.t) - 0.001 && lp > 0);
                });
            }
        });
    });
}

/* =====================================================================
   CARTELES — se inclinan hacia el cursor
   ===================================================================== */
function setupInclinacionCarteles() {
    if (REDUCIDO) return;
    document.querySelectorAll('[data-tilt]').forEach(el => {
        el.addEventListener('pointermove', (e) => {
            if (e.pointerType !== 'mouse') return;
            const r = el.getBoundingClientRect();
            const px = (e.clientX - r.left) / r.width - 0.5, py = (e.clientY - r.top) / r.height - 0.5;
            el.style.setProperty('--ry', (px * 9).toFixed(2));
            el.style.setProperty('--rx', (-py * 7).toFixed(2));
        });
        el.addEventListener('pointerleave', () => { el.style.setProperty('--rx', 0); el.style.setProperty('--ry', 0); });
    });
}

/* =====================================================================
   CURSOR-SEÑAL — punto, flecha de andén sobre enlaces, puerta sobre botones
   ===================================================================== */
function setupCursor() {
    if (REDUCIDO || !window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;
    const cur = $('cursor');
    if (!cur) return;
    document.documentElement.classList.add('cursor-sum');
    let x = -100, y = -100, cx = -100, cy = -100, estado = 'punto', primero = true;
    const BOTON = 'button, [data-puerta], .btn-hero-cta, .toggle-password, .close-btn, .modal-close, .menu-toggle, .btn-submit';

    document.addEventListener('mousemove', (e) => {
        x = e.clientX; y = e.clientY;
        if (primero) { cx = x; cy = y; primero = false; }
        const t = e.target;
        let nuevo = 'punto';
        if (!t.closest) return;
        if (t.closest('input, textarea, select')) nuevo = 'oculto';
        else if (t.closest(BOTON)) nuevo = 'boton';
        else if (t.closest('a, .riel-estacion')) nuevo = 'enlace';
        if (nuevo !== estado) { estado = nuevo; cur.dataset.estado = nuevo; }
    }, { passive: true });
    document.documentElement.addEventListener('mouseleave', () => { cur.dataset.estado = 'oculto'; });
    document.documentElement.addEventListener('mouseenter', () => { cur.dataset.estado = estado; });

    TICKS.push(() => {
        cx += (x - cx) * 0.35; cy += (y - cy) * 0.35;
        cur.style.transform = `translate3d(${cx.toFixed(1)}px,${cy.toFixed(1)}px,0)`;
    });
}

/* =====================================================================
   TORNIQUETE — la tarjeta pasa por el lector, luz verde y se abre el modal
   ===================================================================== */
function entrarPorTorniquete(btn, desdeMenu) {
    if (btn.classList.contains('pasando')) return;
    const abrir = () => {
        btn.classList.remove('pasando', 'acepta');
        if (desdeMenu) {
            const m = document.getElementById('mobileMenu');
            if (m && m.classList.contains('active')) toggleMenu();
        }
        abrirLogin();
    };
    if (REDUCIDO) { abrir(); return; }
    btn.classList.add('pasando');
    setTimeout(() => btn.classList.add('acepta'), 360);
    setTimeout(abrir, 900);
}

/* ---------- Teclado: Esc cierra modales y menú ---------- */
function setupTeclado() {
    document.addEventListener('keydown', (e) => {
        if (e.key !== 'Escape') return;
        const activo = (id) => { const el = document.getElementById(id); return el && el.classList.contains('active'); };
        if (activo('forgotModal')) cerrarRecuperar();
        if (activo('registerModal')) cerrarRegistro();
        if (activo('loginModal')) cerrarLogin();
        if (activo('mobileMenu')) toggleMenu();
    });
}

/* ---------- Bucle único compartido ---------- */
function arrancarBucle() {
    let ultimo = performance.now();
    const cuadro = (t) => {
        // Tiempo real transcurrido (tope 250 ms por si la pestaña estuvo dormida): así la velocidad es correcta aunque bajen los fps
        const dt = clamp((t - ultimo) / 1000, 0.004, 0.25);
        ultimo = t;
        for (let i = 0; i < TICKS.length; i++) {
            try { TICKS[i](t, dt); } catch (err) { console.error('[SUM] tick', err); }
        }
        requestAnimationFrame(cuadro);
    };
    requestAnimationFrame(cuadro);
}