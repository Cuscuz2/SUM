<?php

header("Content-Type: application/json");
require_once "config.php";

try {
    $lineas = $pdo->query(
        "SELECT clave, nombre, tipo, color FROM lineas ORDER BY orden, nombre"
    )->fetchAll();

    $filas = $pdo->query(
        "SELECT le.linea_clave, e.id, e.nombre, e.lat, e.lon, e.dir
         FROM linea_estaciones le
         JOIN estaciones e ON e.id = le.estacion_id
         ORDER BY le.linea_clave, le.orden"
    )->fetchAll();

    $porLinea = [];
    foreach ($filas as $f) {
        $porLinea[$f["linea_clave"]][] = [
            "id"     => (int) $f["id"],
            "nombre" => $f["nombre"],
            "lat"    => (float) $f["lat"],
            "lon"    => (float) $f["lon"],
            "dir"    => $f["dir"],
        ];
    }

    $salida = [];
    foreach ($lineas as $l) {
        $estaciones = $porLinea[$l["clave"]] ?? [];
        if (count($estaciones) < 2) continue;
        $salida[] = [
            "clave"      => $l["clave"],
            "nombre"     => $l["nombre"],
            "tipo"       => $l["tipo"],
            "color"      => $l["color"],
            "estaciones" => $estaciones,
        ];
    }

    $usadas = [];
    foreach ($salida as $l) {
        foreach ($l["estaciones"] as $e) {
            $usadas[$e["id"]] = true;
        }
    }

    $todas = $pdo->query(
        "SELECT id, nombre, lat, lon, dir FROM estaciones ORDER BY nombre"
    )->fetchAll();

    $sueltas = [];
    foreach ($todas as $e) {
        if (isset($usadas[(int) $e["id"]])) continue;
        $sueltas[] = [
            "id"     => (int) $e["id"],
            "nombre" => $e["nombre"],
            "lat"    => (float) $e["lat"],
            "lon"    => (float) $e["lon"],
            "dir"    => $e["dir"],
        ];
    }

    echo json_encode(["exito" => true, "lineas" => $salida, "estaciones_sueltas" => $sueltas]);
} catch (Throwable $e) {
    error_log("Error en red.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(["exito" => false, "mensaje" => "No se pudo cargar la red."]);
}
