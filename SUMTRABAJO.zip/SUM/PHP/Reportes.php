<?php
/**
 * PHP/reportes.php
 *
 * Estadísticas generales de todo el sistema (no de un usuario en particular),
 * para la vista "Reportes y estadísticas" del panel admin.
 * Devuelve KPIs con comparación vs. mes anterior, serie diaria (30 días),
 * horas pico, días de la semana, uso por línea, rutas y estaciones top.
 */

header("Content-Type: application/json");
session_start();
require_once "config.php";

if (empty($_SESSION["es_admin"])) {
    http_response_code(403);
    echo json_encode(["exito" => false, "mensaje" => "Acceso solo para administradores."]);
    exit;
}

/* ---------- Usuarios ---------- */
$u = $pdo->query(
    "SELECT COUNT(*) AS total,
            COALESCE(SUM(activo = 1), 0) AS activos,
            COALESCE(SUM(YEAR(creado_en) = YEAR(CURDATE()) AND MONTH(creado_en) = MONTH(CURDATE())), 0) AS nuevos_mes
     FROM usuarios"
)->fetch();

/* ---------- Mes actual vs. mes anterior ---------- */
function resumenMes(PDO $pdo, string $desde, string $hasta): array {
    $st = $pdo->prepare(
        "SELECT COUNT(*) AS viajes,
                COALESCE(SUM(costo), 0) AS ingresos,
                COALESCE(AVG(duracion_min), 0) AS duracion_prom,
                COUNT(DISTINCT usuario_id) AS usuarios
         FROM viajes
         WHERE fecha_hora >= ? AND fecha_hora < ?"
    );
    $st->execute([$desde, $hasta]);
    return $st->fetch();
}
$ini     = date("Y-m-01");
$iniSig  = date("Y-m-01", strtotime("+1 month", strtotime($ini)));
$iniPrev = date("Y-m-01", strtotime("-1 month", strtotime($ini)));
$mes  = resumenMes($pdo, $ini, $iniSig);
$prev = resumenMes($pdo, $iniPrev, $ini);

/* ---------- Serie diaria: últimos 30 días (rellena días sin viajes) ---------- */
$filas = $pdo->query(
    "SELECT DATE(fecha_hora) AS dia, COUNT(*) AS viajes, COALESCE(SUM(costo), 0) AS ingresos
     FROM viajes
     WHERE fecha_hora >= DATE_SUB(CURDATE(), INTERVAL 29 DAY)
     GROUP BY DATE(fecha_hora)"
)->fetchAll();
$porDia = [];
foreach ($filas as $f) { $porDia[$f["dia"]] = $f; }
$serie = [];
for ($i = 29; $i >= 0; $i--) {
    $d = date("Y-m-d", strtotime("-$i day"));
    $serie[] = [
        "dia"      => $d,
        "viajes"   => (int) ($porDia[$d]["viajes"] ?? 0),
        "ingresos" => (int) ($porDia[$d]["ingresos"] ?? 0),
    ];
}

/* ---------- Horas pico (0-23) ---------- */
$horas = array_fill(0, 24, 0);
foreach ($pdo->query("SELECT HOUR(fecha_hora) AS h, COUNT(*) AS n FROM viajes GROUP BY HOUR(fecha_hora)") as $r) {
    $horas[(int) $r["h"]] = (int) $r["n"];
}

/* ---------- Día de la semana (0 = lunes ... 6 = domingo) ---------- */
$semana = array_fill(0, 7, 0);
foreach ($pdo->query("SELECT WEEKDAY(fecha_hora) AS d, COUNT(*) AS n FROM viajes GROUP BY WEEKDAY(fecha_hora)") as $r) {
    $semana[(int) $r["d"]] = (int) $r["n"];
}

/* ---------- Uso por línea (un viaje "Línea A + Metrocable" suma a ambas) ---------- */
$lineas = [];
foreach ($pdo->query("SELECT linea, COUNT(*) AS n FROM viajes GROUP BY linea") as $r) {
    foreach (explode("+", $r["linea"]) as $parte) {
        $nombre = trim($parte);
        if ($nombre === "") continue;
        $lineas[$nombre] = ($lineas[$nombre] ?? 0) + (int) $r["n"];
    }
}
arsort($lineas);
$lineasOut = [];
foreach ($lineas as $nombre => $n) { $lineasOut[] = ["linea" => $nombre, "viajes" => $n]; }

/* ---------- Rutas más frecuentes ---------- */
$rutas = $pdo->query(
    "SELECT estacion_origen, estacion_destino, COUNT(*) AS veces
     FROM viajes
     GROUP BY estacion_origen, estacion_destino
     ORDER BY veces DESC
     LIMIT 6"
)->fetchAll();
foreach ($rutas as &$r) { $r["veces"] = (int) $r["veces"]; }
unset($r);

/* ---------- Estaciones más usadas (origen + destino) ---------- */
$estaciones = $pdo->query(
    "SELECT estacion, COUNT(*) AS veces FROM (
         SELECT estacion_origen  AS estacion FROM viajes
         UNION ALL
         SELECT estacion_destino AS estacion FROM viajes
     ) t
     GROUP BY estacion
     ORDER BY veces DESC
     LIMIT 6"
)->fetchAll();
foreach ($estaciones as &$e) { $e["veces"] = (int) $e["veces"]; }
unset($e);

/* ---------- Usuarios por tarifa ---------- */
$tarifas = $pdo->query(
    "SELECT COALESCE(tarifa_clave, 'sin_tarifa') AS tarifa, COUNT(*) AS n
     FROM usuarios GROUP BY tarifa_clave ORDER BY n DESC"
)->fetchAll();
foreach ($tarifas as &$t) { $t["n"] = (int) $t["n"]; }
unset($t);

echo json_encode([
    "exito" => true,

    // Compatibilidad con la versión anterior
    "usuarios_total"   => (int) $u["total"],
    "viajes_mes"       => (int) $mes["viajes"],
    "ingresos_mes"     => (int) $mes["ingresos"],
    "rutas_frecuentes" => $rutas,

    // Nuevos datos
    "usuarios_activos"   => (int) $u["activos"],
    "usuarios_nuevos_mes"=> (int) $u["nuevos_mes"],
    "mes_actual"   => [
        "viajes"        => (int) $mes["viajes"],
        "ingresos"      => (int) $mes["ingresos"],
        "duracion_prom" => round((float) $mes["duracion_prom"], 1),
        "usuarios"      => (int) $mes["usuarios"],
    ],
    "mes_anterior" => [
        "viajes"        => (int) $prev["viajes"],
        "ingresos"      => (int) $prev["ingresos"],
        "duracion_prom" => round((float) $prev["duracion_prom"], 1),
        "usuarios"      => (int) $prev["usuarios"],
    ],
    "serie_diaria"       => $serie,
    "horas"              => $horas,
    "semana"             => $semana,
    "lineas"             => $lineasOut,
    "estaciones_top"     => $estaciones,
    "usuarios_por_tarifa"=> $tarifas,
]);
