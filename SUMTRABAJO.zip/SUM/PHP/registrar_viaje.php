<?php

header("Content-Type: application/json");
session_start();
require_once "config.php";

require_once "auth.php";
$usuarioId = exigir_usuario_activo($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["exito" => false, "mensaje" => "Método no permitido."]);
    exit;
}

$datos = json_decode(file_get_contents("php://input"), true) ?? [];

$origen  = trim((string) ($datos["origen"]  ?? ""));
$destino = trim((string) ($datos["destino"] ?? ""));
$linea   = trim((string) ($datos["linea"]   ?? ""));
$minutos = (int) ($datos["minutos"] ?? 0);
$costo   = (int) ($datos["costo"]   ?? 0);

if ($origen === "" || $destino === "" || $minutos <= 0 || $costo < 0) {
    http_response_code(400);
    echo json_encode(["exito" => false, "mensaje" => "Datos de viaje incompletos."]);
    exit;
}

$stmt = $pdo->prepare(
    "INSERT INTO viajes (usuario_id, estacion_origen, estacion_destino, linea, duracion_min, costo, fecha_hora)
     VALUES (?, ?, ?, ?, ?, ?, NOW())"
);
$stmt->execute([$usuarioId, $origen, $destino, $linea, $minutos, $costo]);

echo json_encode(["exito" => true, "id" => $pdo->lastInsertId()]);
