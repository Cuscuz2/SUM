// admin.js — Panel de Administración SUM
// Cada sección está conectada a endpoints reales en ../PHP/.

const API_BASE = '../PHP/';
let usuariosCache = [];

document.addEventListener('DOMContentLoaded', async () => {
    if (window.lucide) lucide.createIcons();

    const sesionOk = await verificarSesionAdmin();
    if (!sesionOk) return; // ya se redirigió a mapa.html

    configurarNavegacionAdmin();
    configurarAcciones();

    cargarTarifasAdmin();
    cargarUsuariosAdmin();
    cargarReportes();
    cargarAvisos();
});

/* ---------- Protege esta página: solo accesible tras validar la contraseña ---------- */
async function verificarSesionAdmin() {
    try {
        const res = await fetch(API_BASE + 'sesion_admin.php', {
            method: 'GET',
            credentials: 'same-origin'
        });
        const data = await res.json();
        if (!data.exito) {
            window.location.href = '../MAPA/mapa.html';
            return false;
        }
        return true;
    } catch (err) {
        console.warn('No se pudo verificar la sesión de administrador:', err);
        window.location.href = '../MAPA/mapa.html';
        return false;
    }
}

/* ---------- Navegación entre secciones del panel ---------- */
function configurarNavegacionAdmin() {
    const navItems = document.querySelectorAll('.dash-nav-item[data-target]');
    const views = document.querySelectorAll('.dash-view');

    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = item.getAttribute('data-target');
            if (!targetId) return;

            views.forEach(v => v.classList.remove('active'));
            navItems.forEach(i => i.classList.remove('active'));

            const targetView = document.getElementById(targetId);
            if (targetView) targetView.classList.add('active');
            item.classList.add('active');

            if (window.lucide) lucide.createIcons();
            if (targetId === 'view-estaciones') abrirVistaEstaciones();
        });
    });

    const btnCerrar = document.getElementById('btnCerrarSesionAdmin');
    if (btnCerrar) {
        btnCerrar.addEventListener('click', async (e) => {
            e.preventDefault();
            try {
                await fetch(API_BASE + 'cerrar_sesion_admin.php', {
                    method: 'POST',
                    credentials: 'same-origin'
                });
            } catch (err) {
                console.warn('No se pudo cerrar la sesión de administrador:', err);
            }
            window.location.href = '../MAPA/mapa.html';
        });
    }
}

/* =========================================================
   TARIFAS Y PRECIOS
   ========================================================= */

async function cargarTarifasAdmin() {
    try {
        const res = await fetch(API_BASE + 'tarifas.php', { credentials: 'same-origin' });
        const data = await res.json();
        if (!data.exito) return;

        data.tarifas.forEach(t => {
            const input = document.querySelector(`input[data-clave="${t.clave}"]`);
            if (input) input.value = t.valor;
        });
    } catch (err) {
        console.warn('Error al cargar tarifas:', err);
    }
}

async function guardarTarifas() {
    const inputs = document.querySelectorAll('input[data-clave]');
    const tarifas = {};
    inputs.forEach(input => { tarifas[input.dataset.clave] = Number(input.value); });

    try {
        const res = await fetch(API_BASE + 'actualizar_tarifas.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify({ tarifas })
        });
        const data = await res.json();
        mostrarToastAdmin(data.exito ? 'Tarifas actualizadas correctamente.' : (data.mensaje || 'No se pudieron guardar las tarifas.'));
    } catch (err) {
        mostrarToastAdmin('Error de red al guardar las tarifas.');
        console.warn(err);
    }
}

/* =========================================================
   USUARIOS REGISTRADOS
   ========================================================= */

async function cargarUsuariosAdmin() {
    const tbody = document.getElementById('tablaUsuarios');
    if (!tbody) return;

    try {
        const res = await fetch(API_BASE + 'usuarios_admin.php', { credentials: 'same-origin' });
        const data = await res.json();

        if (!data.exito) {
            tbody.innerHTML = `<tr><td colspan="6" class="admin-placeholder-text">${data.mensaje || 'No se pudo cargar la lista.'}</td></tr>`;
            return;
        }

        usuariosCache = data.usuarios; // se guarda para poder filtrar sin volver a pedir al servidor
        renderizarTablaUsuarios(usuariosCache);
    } catch (err) {
        tbody.innerHTML = `<tr><td colspan="6" class="admin-placeholder-text">Error de red al cargar usuarios.</td></tr>`;
        console.warn(err);
    }
}

function renderizarTablaUsuarios(usuarios) {
    const tbody = document.getElementById('tablaUsuarios');
    if (!tbody) return;

    if (!usuarios.length) {
        tbody.innerHTML = `<tr><td colspan="6" class="admin-placeholder-text">No se encontraron usuarios.</td></tr>`;
        return;
    }

    tbody.innerHTML = usuarios.map(u => {
        const activo = Number(u.activo) === 1;
        const fecha = new Date(u.creado_en.replace(' ', 'T')).toLocaleDateString('es-CO');
        return `
            <tr data-usuario-id="${u.id}">
                <td>${escaparHtml(u.nombre)}</td>
                <td>@${escaparHtml(u.usuario)}</td>
                <td>${escaparHtml(u.email)}</td>
                <td>${fecha}</td>
                <td>
                    <span class="admin-status ${activo ? 'admin-status--ok' : 'admin-status--off'}">
                        ${activo ? 'Activo' : 'Suspendido'}
                    </span>
                </td>
                <td class="admin-row-actions">
                    <button class="admin-icon-btn ${activo ? 'admin-icon-btn--danger' : ''}"
                            title="${activo ? 'Suspender' : 'Activar'}"
                            data-accion="toggle-usuario"
                            data-activo-actual="${activo ? 1 : 0}">
                        <i data-lucide="${activo ? 'ban' : 'check'}"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('');

    if (window.lucide) lucide.createIcons();
}

function filtrarUsuarios(texto) {
    const q = texto.trim().toLowerCase();
    if (!q) {
        renderizarTablaUsuarios(usuariosCache);
        return;
    }
    const filtrados = usuariosCache.filter(u =>
        u.nombre.toLowerCase().includes(q) ||
        u.usuario.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q)
    );
    renderizarTablaUsuarios(filtrados);
}

async function alternarEstadoUsuario(usuarioId, activoActual) {
    const nuevoEstado = activoActual === 1 ? 0 : 1;
    try {
        const res = await fetch(API_BASE + 'suspender_usuario.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify({ usuario_id: usuarioId, activo: nuevoEstado })
        });
        const data = await res.json();
        if (data.exito) {
            mostrarToastAdmin(nuevoEstado === 1 ? 'Cuenta activada.' : 'Cuenta suspendida.');
            cargarUsuariosAdmin();
        } else {
            mostrarToastAdmin(data.mensaje || 'No se pudo cambiar el estado.');
        }
    } catch (err) {
        mostrarToastAdmin('Error de red al cambiar el estado.');
        console.warn(err);
    }
}

/* =========================================================
   REPORTES Y ESTADÍSTICAS
   ========================================================= */

let reportesData = null;
let serieActiva = 'viajes';
const REP_COLORES = ['#008037', '#2fb36b', '#7ad3a0', '#f59e0b', '#3b82f6', '#a78bfa', '#94a3b8'];
const DIAS_SEMANA = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
const DIAS_LARGO = ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo'];

const fmtNum = n => Number(n || 0).toLocaleString('es-CO').replace(/,/g, '.');
const fmtMoney = n => '$' + fmtNum(n);
const fmtCorto = n => n >= 1e6 ? (n / 1e6).toFixed(1).replace('.', ',') + ' M' : n >= 1e3 ? Math.round(n / 1e3) + ' mil' : String(n);

async function cargarReportes() {
    const btn = document.getElementById('repRefrescar');
    if (btn) btn.classList.add('girando');
    try {
        const res = await fetch(API_BASE + 'reportes.php', { credentials: 'same-origin' });
        const data = await res.json();
        if (!data.exito) return;
        reportesData = data;
        renderReportes(data);
    } catch (err) {
        console.warn('Error al cargar reportes:', err);
    } finally {
        if (btn) setTimeout(() => btn.classList.remove('girando'), 500);
    }
}

function renderReportes(d) {
    const serie = d.serie_diaria || [];
    const act = d.mes_actual || {}, prev = d.mes_anterior || {};

    // --- KPIs con conteo animado ---
    animarNumero('statUsuariosTotal', d.usuarios_total, fmtNum);
    animarNumero('statViajesTotal', act.viajes, fmtNum);
    animarNumero('statIngresoTotal', act.ingresos, fmtMoney);
    animarNumero('kpiDuracion', act.duracion_prom, v => v.toFixed(1).replace('.', ',') + ' min', 1);

    setText('kpiUsuariosSub', `${d.usuarios_activos} activos · +${d.usuarios_nuevos_mes} este mes`);
    setDelta('kpiViajesDelta', act.viajes, prev.viajes);
    setDelta('kpiIngresosDelta', act.ingresos, prev.ingresos);
    setText('kpiDuracionSub', `${act.usuarios || 0} usuarios viajaron este mes`);

    // Sparklines (solo donde hay serie real)
    dibujarSpark('sparkViajes', serie.map(x => x.viajes));
    dibujarSpark('sparkIngresos', serie.map(x => x.ingresos));

    // --- Gráficos ---
    dibujarTendencia(serie, serieActiva);
    dibujarBarras('chartHoras', d.horas || [], i => String(i).padStart(2, '0') + ':00', i => (i % 3 === 0 ? String(i) : ''), 'viajes');
    dibujarBarras('chartSemana', d.semana || [], i => DIAS_LARGO[i], i => DIAS_SEMANA[i], 'viajes');
    dibujarDona(d.lineas || []);
    dibujarRanking('rankEstaciones', (d.estaciones_top || []).map(e => ({ nombre: escaparHtml(e.estacion), n: e.veces })), 'viajes');
    dibujarRanking('rutasFrecuentesLista', (d.rutas_frecuentes || []).map(r => ({ nombre: `${escaparHtml(r.estacion_origen)} <small>→</small> ${escaparHtml(r.estacion_destino)}`, n: r.veces })), 'viajes');

    // Textos de apoyo
    const horas = d.horas || [];
    const maxH = Math.max(...horas, 0);
    setHtml('repHoraPico', maxH ? `Mayor afluencia a las <b>${String(horas.indexOf(maxH)).padStart(2, '0')}:00</b> (${maxH} viajes)` : 'Aún sin datos');
    const sem = d.semana || [];
    const maxS = Math.max(...sem, 0);
    setHtml('repDiaFuerte', maxS ? `Día más movido: <b>${DIAS_LARGO[sem.indexOf(maxS)]}</b>` : 'Aún sin datos');
    const total30 = serie.reduce((a, x) => a + x.viajes, 0);
    const ing30 = serie.reduce((a, x) => a + x.ingresos, 0);
    setHtml('repTendenciaResumen', `<b>${fmtNum(total30)}</b> viajes y <b>${fmtMoney(ing30)}</b> en ingresos`);
}

/* ---------- utilidades ---------- */
function setText(id, t) { const el = document.getElementById(id); if (el) el.textContent = t; }
function setHtml(id, t) { const el = document.getElementById(id); if (el) el.innerHTML = t; }

function setDelta(id, actual, previo) {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.remove('sube', 'baja');
    if (!previo) { el.textContent = actual ? 'Sin mes anterior para comparar' : 'Sin movimiento'; return; }
    const pct = ((actual - previo) / previo) * 100;
    const flecha = pct >= 0 ? '▲' : '▼';
    el.classList.add(pct >= 0 ? 'sube' : 'baja');
    el.textContent = `${flecha} ${Math.abs(pct).toFixed(0)}% vs. mes anterior`;
}

function animarNumero(id, destino, formato, decimales = 0) {
    const el = document.getElementById(id);
    if (!el) return;
    destino = Number(destino) || 0;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = formato(destino); return; }
    const t0 = performance.now(), dur = 1100;
    (function paso(t) {
        const k = Math.min(1, (t - t0) / dur);
        const ease = 1 - Math.pow(1 - k, 3);
        const v = destino * ease;
        el.textContent = formato(decimales ? v : Math.round(v));
        if (k < 1) requestAnimationFrame(paso);
        else el.textContent = formato(destino);
    })(t0);
}

function dibujarSpark(id, valores) {
    const svg = document.getElementById(id);
    if (!svg || !valores.length) return;
    const max = Math.max(...valores, 1), min = Math.min(...valores, 0);
    const pts = valores.map((v, i) => [
        (i / Math.max(valores.length - 1, 1)) * 100,
        28 - ((v - min) / (max - min || 1)) * 24
    ]);
    const linea = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
    svg.innerHTML = `<path class="a" d="${linea} L100 30 L0 30 Z"/><path class="l" d="${linea}"/>`;
}

function tooltipDe(cont) {
    let tip = cont.querySelector('.rep-tip');
    if (!tip) { tip = document.createElement('div'); tip.className = 'rep-tip'; cont.appendChild(tip); }
    return tip;
}
function moverTip(tip, cont, x, y, html) {
    const r = cont.getBoundingClientRect();
    tip.innerHTML = html;
    tip.style.left = Math.min(Math.max(x, 50), r.width - 50) + 'px';
    tip.style.top = y + 'px';
    tip.classList.add('on');
}

/* ---------- Tendencia (área + línea, con cursor interactivo) ---------- */
function dibujarTendencia(serie, campo) {
    const cont = document.getElementById('chartTendencia');
    if (!cont || !serie.length) return;
    const W = Math.max(cont.clientWidth, 320), H = Math.max(cont.clientHeight, 200), pl = 44, pr = 12, pt = 14, pb = 28;
    const vals = serie.map(x => x[campo]);
    const max = niceMax(Math.max(...vals, 1));
    const X = i => pl + (i / (serie.length - 1)) * (W - pl - pr);
    const Y = v => pt + (1 - v / max) * (H - pt - pb);
    const pts = serie.map((x, i) => [X(i), Y(x[campo])]);
    const linea = suave(pts, pt, H - pb);
    const area = `${linea} L${X(serie.length - 1)} ${H - pb} L${X(0)} ${H - pb} Z`;

    let grid = '';
    for (let g = 0; g <= 4; g++) {
        const v = (max / 4) * g, y = Y(v);
        grid += `<line class="grid" x1="${pl}" x2="${W - pr}" y1="${y}" y2="${y}"/><text x="${pl - 8}" y="${y + 3}" text-anchor="end">${campo === 'ingresos' ? fmtCorto(v) : Math.round(v)}</text>`;
    }
    let ejeX = '';
    serie.forEach((x, i) => {
        if (i % 5 === 0 || i === serie.length - 1) {
            const f = new Date(x.dia + 'T00:00:00');
            ejeX += `<text x="${X(i)}" y="${H - 8}" text-anchor="middle">${f.getDate()}/${f.getMonth() + 1}</text>`;
        }
    });
    const ancho = (W - pl - pr) / (serie.length - 1);
    const hits = serie.map((x, i) => `<rect class="hit" data-i="${i}" x="${X(i) - ancho / 2}" y="${pt}" width="${ancho}" height="${H - pt - pb}"/>`).join('');

    cont.innerHTML = `<svg viewBox="0 0 ${W} ${H}">
        <defs><linearGradient id="repGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#008037" stop-opacity=".35"/><stop offset="1" stop-color="#008037" stop-opacity="0"/></linearGradient></defs>
        ${grid}${ejeX}
        <path class="area" d="${area}"/>
        <path class="line" d="${linea}" pathLength="1" style="stroke-dasharray:1;stroke-dashoffset:1;transition:stroke-dashoffset 1.3s ease"/>
        <line class="cursor" y1="${pt}" y2="${H - pb}"/>
        <circle class="dot" r="5"/>
        ${hits}
    </svg>`;
    const svg = cont.querySelector('svg'), path = svg.querySelector('.line');
    requestAnimationFrame(() => requestAnimationFrame(() => { path.style.strokeDashoffset = 0; }));

    const tip = tooltipDe(cont), cur = svg.querySelector('.cursor'), dot = svg.querySelector('.dot');
    svg.querySelectorAll('.hit').forEach(h => {
        h.addEventListener('mouseenter', () => {
            const i = +h.dataset.i, x = serie[i];
            cur.setAttribute('x1', X(i)); cur.setAttribute('x2', X(i)); cur.style.opacity = 1;
            dot.setAttribute('cx', X(i)); dot.setAttribute('cy', Y(x[campo])); dot.style.opacity = 1;
            const r = svg.getBoundingClientRect();
            const f = new Date(x.dia + 'T00:00:00').toLocaleDateString('es-CO', { weekday: 'short', day: 'numeric', month: 'short' });
            moverTip(tip, cont, (X(i) / W) * r.width, (Y(x[campo]) / H) * r.height,
                `${campo === 'ingresos' ? fmtMoney(x[campo]) : x[campo] + ' viajes'}<small>${f}</small>`);
        });
    });
    svg.addEventListener('mouseleave', () => { cur.style.opacity = 0; dot.style.opacity = 0; tip.classList.remove('on'); });
}

function niceMax(v) {
    const pot = Math.pow(10, Math.floor(Math.log10(v)));
    const n = v / pot;
    return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * pot;
}
function suave(p, yMin = -Infinity, yMax = Infinity) { // curva Catmull-Rom → Bézier
    if (p.length < 3) return p.map((q, i) => (i ? 'L' : 'M') + q[0] + ' ' + q[1]).join(' ');
    let d = `M${p[0][0]} ${p[0][1]}`;
    for (let i = 0; i < p.length - 1; i++) {
        const p0 = p[i - 1] || p[i], p1 = p[i], p2 = p[i + 1], p3 = p[i + 2] || p2;
        const c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = Math.min(yMax, Math.max(yMin, p1[1] + (p2[1] - p0[1]) / 6));
        const c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = Math.min(yMax, Math.max(yMin, p2[1] - (p3[1] - p1[1]) / 6));
        d += ` C${c1x.toFixed(1)} ${c1y.toFixed(1)}, ${c2x.toFixed(1)} ${c2y.toFixed(1)}, ${p2[0].toFixed(1)} ${p2[1].toFixed(1)}`;
    }
    return d;
}

/* ---------- Barras (horas / días) ---------- */
function dibujarBarras(id, valores, etiquetaTip, etiquetaEje, unidad) {
    const cont = document.getElementById(id);
    if (!cont) return;
    const W = Math.max(cont.clientWidth, 240), H = Math.max(cont.clientHeight, 160), pl = 6, pr = 6, pt = 10, pb = 24;
    const max = Math.max(...valores, 1);
    const n = valores.length, paso = (W - pl - pr) / n, bw = paso * 0.68;
    const maxIdx = valores.indexOf(Math.max(...valores));
    let barras = '';
    valores.forEach((v, i) => {
        const h = Math.max((v / max) * (H - pt - pb), v ? 3 : 2);
        const x = pl + i * paso + (paso - bw) / 2, y = H - pb - h;
        barras += `<g class="barhit" data-i="${i}"><rect x="${pl + i * paso}" y="${pt}" width="${paso}" height="${H - pt - pb}" fill="transparent"/>
            <rect class="bar${v && i === maxIdx ? ' peak' : ''}" style="--k:${i}" x="${x}" y="${y}" width="${bw}" height="${h}" rx="${Math.min(bw / 2, 5)}"/></g>`;
        const e = etiquetaEje(i);
        if (e) barras += `<text x="${x + bw / 2}" y="${H - 7}" text-anchor="middle">${e}</text>`;
    });
    cont.innerHTML = `<svg viewBox="0 0 ${W} ${H}"><line class="grid" x1="${pl}" x2="${W - pr}" y1="${H - pb}" y2="${H - pb}"/>${barras}</svg>`;
    const tip = tooltipDe(cont), svg = cont.querySelector('svg');
    cont.querySelectorAll('.barhit').forEach(g => {
        g.addEventListener('mouseenter', () => {
            const i = +g.dataset.i, r = svg.getBoundingClientRect();
            const h = Math.max((valores[i] / max) * (H - pt - pb), 2);
            moverTip(tip, cont, ((pl + i * paso + paso / 2) / W) * r.width, ((H - pb - h) / H) * r.height,
                `${valores[i]} ${unidad}<small>${etiquetaTip(i)}</small>`);
        });
        g.addEventListener('mouseleave', () => tip.classList.remove('on'));
    });
}

/* ---------- Dona de líneas ---------- */
function dibujarDona(lineas) {
    const cont = document.getElementById('chartLineas'), leyenda = document.getElementById('legendLineas');
    if (!cont || !leyenda) return;
    const total = lineas.reduce((a, l) => a + l.viajes, 0);
    if (!total) { cont.innerHTML = ''; leyenda.innerHTML = '<li class="rep-empty">Todavía no hay viajes registrados.</li>'; return; }
    const R = 70, C = 2 * Math.PI * R;
    let acum = 0, segs = '';
    lineas.forEach((l, i) => {
        const frac = l.viajes / total, len = frac * C;
        segs += `<circle class="seg" data-i="${i}" cx="85" cy="85" r="${R}" stroke="${REP_COLORES[i % REP_COLORES.length]}"
            stroke-dasharray="0 ${C}" stroke-dashoffset="${-acum}" data-len="${Math.max(len - 2, 0)}" data-c="${C}"/>`;
        acum += len;
    });
    cont.innerHTML = `<svg viewBox="0 0 170 170">${segs}</svg>
        <div class="rep-donut-center"><strong id="donutNum">${fmtNum(total)}</strong><span id="donutTxt">trayectos por línea</span></div>`;
    leyenda.innerHTML = lineas.map((l, i) => `<li data-i="${i}"><i style="background:${REP_COLORES[i % REP_COLORES.length]}"></i>${escaparHtml(l.linea)}<em><b>${l.viajes}</b> · ${Math.round(l.viajes / total * 100)}%</em></li>`).join('');

    // animación de entrada
    requestAnimationFrame(() => requestAnimationFrame(() => cont.querySelectorAll('circle.seg').forEach((c, i) => {
        c.style.transition = `stroke-dasharray .9s ${i * 120}ms cubic-bezier(.2,.8,.2,1), stroke-width .2s, opacity .2s`;
        c.setAttribute('stroke-dasharray', `${c.dataset.len} ${c.dataset.c}`);
    })));

    // interacción dona <-> leyenda
    const resaltar = i => {
        cont.classList.toggle('hovering', i !== null);
        cont.querySelectorAll('circle.seg').forEach(c => c.classList.toggle('on', +c.dataset.i === i));
        leyenda.querySelectorAll('li').forEach(li => li.classList.toggle('on', +li.dataset.i === i));
        const l = i !== null ? lineas[i] : null;
        setText('donutNum', l ? l.viajes : fmtNum(total));
        setText('donutTxt', l ? l.linea : 'trayectos por línea');
    };
    cont.querySelectorAll('circle.seg').forEach(c => { c.addEventListener('mouseenter', () => resaltar(+c.dataset.i)); c.addEventListener('mouseleave', () => resaltar(null)); });
    leyenda.querySelectorAll('li[data-i]').forEach(li => { li.addEventListener('mouseenter', () => resaltar(+li.dataset.i)); li.addEventListener('mouseleave', () => resaltar(null)); });
}

/* ---------- Rankings con barras de progreso ---------- */
function dibujarRanking(id, items, unidad) {
    const ol = document.getElementById(id);
    if (!ol) return;
    if (!items.length) { ol.innerHTML = '<li class="rep-empty">Todavía no hay viajes registrados.</li>'; return; }
    const max = Math.max(...items.map(i => i.n), 1);
    ol.innerHTML = items.map((it, i) => `<li>
        <span class="pos">${i + 1}</span><span class="nom" title="${it.nombre.replace(/<[^>]+>/g, '')}">${it.nombre}</span><span class="num">${it.n}</span>
        <span class="track"><span class="fill" data-w="${(it.n / max) * 100}"></span></span></li>`).join('');
    requestAnimationFrame(() => requestAnimationFrame(() => ol.querySelectorAll('.fill').forEach((f, i) => {
        f.style.transitionDelay = (i * 90) + 'ms';
        f.style.width = f.dataset.w + '%';
    })));
}

/* ---------- Controles de la vista ---------- */
document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('repRefrescar');
    if (btn) btn.addEventListener('click', cargarReportes);
    document.querySelectorAll('#repToggleSerie button').forEach(b => b.addEventListener('click', () => {
        serieActiva = b.dataset.serie;
        document.querySelectorAll('#repToggleSerie button').forEach(x => x.classList.toggle('active', x === b));
        if (reportesData) dibujarTendencia(reportesData.serie_diaria, serieActiva);
    }));
    // Redibuja cuando la vista pasa de oculta a visible o cambia de ancho
    const contRep = document.querySelector('#view-reportes .rep-container');
    if (contRep && window.ResizeObserver) {
        let ultimoAncho = 0, rt;
        new ResizeObserver(() => {
            const w = Math.round(contRep.clientWidth);
            if (!w || w === ultimoAncho) return;
            ultimoAncho = w;
            clearTimeout(rt);
            rt = setTimeout(() => { if (reportesData) renderReportes(reportesData); }, 120);
        }).observe(contRep);
    }
});

/* =========================================================
   AVISOS Y NOTIFICACIONES
   ========================================================= */

async function cargarAvisos() {
    const lista = document.getElementById('avisosLista');
    if (!lista) return;

    try {
        const res = await fetch(API_BASE + 'avisos.php', { credentials: 'same-origin' });
        const data = await res.json();
        if (!data.exito || !data.avisos.length) {
            lista.textContent = 'Todavía no se ha enviado ningún aviso.';
            return;
        }
        lista.innerHTML = data.avisos
            .map(a => `<strong>${escaparHtml(a.titulo)}</strong> — ${escaparHtml(a.mensaje)}`)
            .join('<br><br>');
    } catch (err) {
        lista.textContent = 'Error de red al cargar los avisos.';
        console.warn(err);
    }
}

async function enviarAviso(titulo, mensaje, destino) {
    try {
        const res = await fetch(API_BASE + 'avisos.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify({ titulo, mensaje, destino })
        });
        const data = await res.json();
        if (data.exito) {
            mostrarToastAdmin('Aviso enviado.');
            cargarAvisos();
        } else {
            mostrarToastAdmin(data.mensaje || 'No se pudo enviar el aviso.');
        }
    } catch (err) {
        mostrarToastAdmin('Error de red al enviar el aviso.');
        console.warn(err);
    }
}

/* ---------- Acciones de los botones ---------- */
function configurarAcciones() {
    const btnGuardarTarifas = document.getElementById('btnGuardarTarifas');
    if (btnGuardarTarifas) {
        btnGuardarTarifas.addEventListener('click', guardarTarifas);
    }

    const btnEnviarAviso = document.getElementById('btnEnviarAviso');
    if (btnEnviarAviso) {
        btnEnviarAviso.addEventListener('click', () => {
            const titulo = document.getElementById('avisoTitulo').value.trim();
            const mensaje = document.getElementById('avisoMensaje').value.trim();
            const destino = document.getElementById('avisoDestino').value;
            if (!titulo || !mensaje) {
                mostrarToastAdmin('Escribe un título y un mensaje.');
                return;
            }
            enviarAviso(titulo, mensaje, destino);
            document.getElementById('avisoTitulo').value = '';
            document.getElementById('avisoMensaje').value = '';
        });
    }

    // Editor de "Estaciones y líneas"
    configurarEditorRed();

    // Delegación de eventos para los botones "Suspender/Activar" de la tabla de usuarios
    const tablaUsuarios = document.getElementById('tablaUsuarios');
    if (tablaUsuarios) {
        tablaUsuarios.addEventListener('click', (e) => {
            const btn = e.target.closest('[data-accion="toggle-usuario"]');
            if (!btn) return;
            const fila = btn.closest('tr[data-usuario-id]');
            if (!fila) return;
            const usuarioId = Number(fila.dataset.usuarioId);
            const activoActual = Number(btn.dataset.activoActual);

            if (activoActual === 1) {
                const u = usuariosCache.find(x => Number(x.id) === usuarioId);
                const quien = u ? `${u.nombre} (@${u.usuario})` : 'este usuario';
                if (!confirm(`¿Suspender la cuenta de ${quien}?\n\nNo podrá iniciar sesión ni usar el sistema hasta que la actives de nuevo.`)) return;
            }
            alternarEstadoUsuario(usuarioId, activoActual);
        });
    }

    // Buscador de "Usuarios registrados"
    const buscarUsuarios = document.getElementById('buscarUsuarios');
    if (buscarUsuarios) {
        buscarUsuarios.addEventListener('input', (e) => filtrarUsuarios(e.target.value));
    }
}

function escaparHtml(texto) {
    const div = document.createElement('div');
    div.textContent = texto ?? '';
    return div.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

let toastAdminTimer = null;
const TOAST_ICONOS_ADMIN = {
    exito: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 13l4 4L19 7"/></svg>',
    error: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 8v5M12 16.5v.5"/><circle cx="12" cy="12" r="9"/></svg>'
};
function mostrarToastAdmin(mensaje, tipo) {
    const toast = document.getElementById('toast');
    if (!toast) return;
    if (!tipo) tipo = /no se pudo|error|escribe|marca|necesita/i.test(mensaje) ? 'error' : 'exito';
    toast.className = 'toast toast-' + tipo;
    toast.innerHTML = '<div class="toast-box" role="status" aria-live="polite">' +
        '<span class="toast-icon">' + TOAST_ICONOS_ADMIN[tipo] + '</span>' +
        '<p class="toast-text"></p></div>';
    toast.querySelector('.toast-text').textContent = mensaje;
    void toast.offsetWidth;
    toast.classList.add('show');
    clearTimeout(toastAdminTimer);
    toastAdminTimer = setTimeout(() => toast.classList.remove('show'), tipo === 'error' ? 2200 : 1600);
}


/* =========================================================
   ESTACIONES Y LÍNEAS
   El administrador edita la red que ven los usuarios en el mapa.
   Datos: ../PHP/admin_red.php (GET lista, POST guarda/elimina).
   ========================================================= */

const CENTRO_MAPA_ADMIN = [6.2472, -75.5697]; // San Antonio
const TRAZO_POR_TIPO = { metro: null, metrocable: '2 8', metroplus: '6 4', tranvia: '2 8' };
const NOMBRE_POR_TIPO = { metro: 'Metro', metrocable: 'Metrocable', metroplus: 'Metroplús', tranvia: 'Tranvía' };

const red = {
    lineas: [],      // [{ clave, nombre, tipo, color, estaciones: [ids en orden], protegida }]
    estaciones: [],  // [{ id, nombre, lat, lon, dir }]
    mapa: null,
    capa: null
};

// Lo que se está editando ahora mismo (o null si se ve solo la lista):
//  { clase: 'linea',    clave, nombre, tipoTransporte, color, estaciones: [ids], insertarDespues, protegida }
//  { clase: 'estacion', id, nombre, dir, lat, lon }
let redEditor = null;

const redEl = (id) => document.getElementById(id);

/* ---------- Entrada a la sección ---------- */
function abrirVistaEstaciones() {
    iniciarMapaAdmin();
    setTimeout(() => { if (red.mapa) red.mapa.invalidateSize(); }, 150);
    if (!redEditor) cargarRedAdmin(); // no se pisa lo que se está editando
}

function iniciarMapaAdmin() {
    if (red.mapa) return;
    const contenedor = redEl('adminMapa');
    if (!contenedor) return;
    if (!window.L) {
        redEl('redMapaHint').textContent = 'No se pudo cargar el mapa. Revisa tu conexión a internet.';
        return;
    }

    red.mapa = L.map('adminMapa', { zoomControl: true }).setView(CENTRO_MAPA_ADMIN, 11);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19
    }).addTo(red.mapa);

    // Al crear o editar una estación, un clic en el mapa fija su ubicación
    red.mapa.on('click', (e) => {
        if (redEditor && redEditor.clase === 'estacion') {
            ubicarEstacionEditada(e.latlng.lat, e.latlng.lng, true);
        }
    });

    actualizarHintMapa();
}

async function cargarRedAdmin() {
    try {
        const res = await fetch(API_BASE + 'admin_red.php', { credentials: 'same-origin' });
        const data = await res.json();
        if (!data.exito) {
            mostrarToastAdmin(data.mensaje || 'No se pudo cargar la red.');
            redEl('redListaLineas').innerHTML = `<p class="red-vacio">${escaparHtml(data.mensaje || 'No se pudo cargar la red.')}</p>`;
            return false;
        }
        red.lineas = data.lineas;
        red.estaciones = data.estaciones;
        renderizarListaLineas();
        renderizarListaEstaciones();
        redibujarMapa();
        return true;
    } catch (err) {
        console.warn('Error al cargar la red:', err);
        mostrarToastAdmin('Error de red al cargar estaciones y líneas.');
        return false;
    }
}

// Todas las acciones de guardado/eliminado pasan por aquí
async function llamarAdminRed(cuerpo) {
    try {
        const res = await fetch(API_BASE + 'admin_red.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify(cuerpo)
        });
        return await res.json();
    } catch (err) {
        console.warn(err);
        return { exito: false, mensaje: 'Error de red. Intenta de nuevo.' };
    }
}

/* ---------- Pestañas y vistas ---------- */
function mostrarPestana(tab) {
    document.querySelectorAll('.red-tab').forEach(b => {
        const activa = b.dataset.redTab === tab;
        b.classList.toggle('active', activa);
        b.setAttribute('aria-selected', String(activa));
    });
    redEl('redTabLineas').classList.toggle('active', tab === 'lineas');
    redEl('redTabEstaciones').classList.toggle('active', tab === 'estaciones');
}

// Vuelve a mostrar las listas (y oculta los formularios) en ambas pestañas
function mostrarListasRed() {
    ['redVistaListaLineas', 'redVistaListaEstaciones'].forEach(id => redEl(id).classList.add('active'));
    ['redVistaEditorLinea', 'redVistaEditorEstacion'].forEach(id => redEl(id).classList.remove('active'));
}

function mostrarVistaEditor(clase) {
    const esLinea = clase === 'linea';
    mostrarPestana(esLinea ? 'lineas' : 'estaciones');
    redEl('redVistaListaLineas').classList.toggle('active', !esLinea);
    redEl('redVistaEditorLinea').classList.toggle('active', esLinea);
    redEl('redVistaListaEstaciones').classList.toggle('active', esLinea);
    redEl('redVistaEditorEstacion').classList.toggle('active', !esLinea);
}

function cambiarPestanaRed(tab) {
    redEditor = null;
    mostrarPestana(tab);
    mostrarListasRed();
    actualizarHintMapa();
    redibujarMapa();
}

function cerrarEditorRed() {
    redEditor = null;
    mostrarListasRed();
    renderizarListaLineas();
    renderizarListaEstaciones();
    actualizarHintMapa();
    redibujarMapa();
}

function actualizarHintMapa() {
    const hint = redEl('redMapaHint');
    if (!hint) return;
    if (redEditor && redEditor.clase === 'linea') {
        hint.textContent = 'Editando el recorrido. Las demás líneas se ven atenuadas.';
    } else if (redEditor && redEditor.clase === 'estacion') {
        hint.textContent = 'Haz clic en el mapa o arrastra el punto verde para fijar la ubicación.';
    } else if (redEl('redTabEstaciones').classList.contains('active')) {
        hint.textContent = 'Haz clic en una estación del mapa o de la lista para editarla.';
    } else {
        hint.textContent = 'Elige una línea de la lista para editar su recorrido.';
    }
}

/* ---------- Listas ---------- */
function estacionesPorId() {
    return new Map(red.estaciones.map(e => [e.id, e]));
}

function lineasDeEstacion(id) {
    return red.lineas.filter(l => l.estaciones.includes(id));
}

function renderizarListaLineas() {
    const cont = redEl('redListaLineas');
    if (!cont) return;
    if (!red.lineas.length) {
        cont.innerHTML = '<p class="red-vacio">Todavía no hay líneas. Crea la primera con el botón de abajo.</p>';
        return;
    }
    cont.innerHTML = red.lineas.map(l => `
        <button type="button" class="red-item" data-clave="${escaparHtml(l.clave)}">
            <span class="red-item-dot" style="background:${escaparHtml(l.color)};"></span>
            <span class="red-item-main">
                <span class="red-item-nombre">${escaparHtml(l.nombre)}</span>
                <span class="red-item-sub">${NOMBRE_POR_TIPO[l.tipo] || l.tipo} · ${l.estaciones.length} ${l.estaciones.length === 1 ? 'estación' : 'estaciones'}</span>
            </span>
            <i data-lucide="chevron-right"></i>
        </button>
    `).join('');
    if (window.lucide) lucide.createIcons();
}

function renderizarListaEstaciones() {
    const cont = redEl('redListaEstaciones');
    if (!cont) return;
    const q = (redEl('redBuscarEstacion').value || '').trim().toLowerCase();
    const lista = red.estaciones.filter(e => !q || e.nombre.toLowerCase().includes(q));

    if (!lista.length) {
        cont.innerHTML = `<p class="red-vacio">${q ? 'No hay estaciones con ese nombre.' : 'Todavía no hay estaciones.'}</p>`;
        return;
    }
    cont.innerHTML = lista.map(e => {
        const ls = lineasDeEstacion(e.id);
        const sub = ls.length
            ? ls.map(l => escaparHtml(l.nombre.split(' · ')[0])).join(', ') + (ls.length > 1 ? ' · transbordo' : '')
            : 'Sin línea asignada';
        const color = ls.length === 0 ? '#94a3b8' : ls.length > 1 ? '#0f172a' : ls[0].color;
        return `
            <button type="button" class="red-item" data-id="${e.id}">
                <span class="red-item-dot" style="background:${escaparHtml(color)};"></span>
                <span class="red-item-main">
                    <span class="red-item-nombre">${escaparHtml(e.nombre)}</span>
                    <span class="red-item-sub">${sub}</span>
                </span>
                <i data-lucide="chevron-right"></i>
            </button>`;
    }).join('');
    if (window.lucide) lucide.createIcons();
}

/* ---------- Editor de línea ---------- */
function abrirEditorLinea(clave) {
    const l = clave ? red.lineas.find(x => x.clave === clave) : null;
    if (clave && !l) return;

    redEditor = {
        clase: 'linea',
        clave: l ? l.clave : null,
        nombre: l ? l.nombre : '',
        tipoTransporte: l ? l.tipo : 'metro',
        color: l ? l.color : '#2563eb',
        estaciones: l ? [...l.estaciones] : [],
        insertarDespues: null, // null = agregar al final
        protegida: !!(l && l.protegida)
    };

    redEl('redTituloLinea').textContent = l ? 'Editar línea' : 'Nueva línea';
    redEl('lineaNombre').value = redEditor.nombre;
    redEl('lineaTipo').value = redEditor.tipoTransporte;
    redEl('lineaColor').value = redEditor.color;
    redEl('btnEliminarLinea').hidden = !l || redEditor.protegida;
    redEl('redNotaProtegida').hidden = !redEditor.protegida;

    mostrarVistaEditor('linea');
    renderizarRecorrido();
    actualizarHintMapa();
    redibujarMapa();
    ajustarMapaAEstaciones(redEditor.estaciones);
    if (window.lucide) lucide.createIcons();
}

function renderizarRecorrido() {
    const ed = redEditor;
    if (!ed || ed.clase !== 'linea') return;
    const porId = estacionesPorId();
    const ol = redEl('redRecorrido');

    redEl('redContadorRecorrido').textContent =
        `${ed.estaciones.length} ${ed.estaciones.length === 1 ? 'estación' : 'estaciones'}`;

    if (!ed.estaciones.length) {
        ol.innerHTML = '<li class="red-vacio">Aún no hay estaciones. Agrégalas con la lista de abajo.</li>';
    } else {
        const ultima = ed.estaciones.length - 1;
        ol.innerHTML = ed.estaciones.map((id, i) => {
            const e = porId.get(id);
            const marcada = ed.insertarDespues === i;
            return `
                <li class="red-paso${marcada ? ' red-paso--marca' : ''}" data-i="${i}">
                    <span class="red-paso-num" style="background:${escaparHtml(ed.color)};">${i + 1}</span>
                    <span class="red-paso-nombre">${escaparHtml(e ? e.nombre : '(estación eliminada)')}</span>
                    <span class="red-paso-acciones">
                        <button type="button" data-accion="despues" class="${marcada ? 'activo' : ''}" title="Agregar una estación justo después de esta" aria-label="Agregar una estación después de ${escaparHtml(e ? e.nombre : '')}"><i data-lucide="plus"></i></button>
                        <button type="button" data-accion="subir" title="Mover arriba" aria-label="Mover arriba" ${i === 0 ? 'disabled' : ''}><i data-lucide="arrow-up"></i></button>
                        <button type="button" data-accion="bajar" title="Mover abajo" aria-label="Mover abajo" ${i === ultima ? 'disabled' : ''}><i data-lucide="arrow-down"></i></button>
                        <button type="button" data-accion="quitar" title="Quitar del recorrido" aria-label="Quitar del recorrido"><i data-lucide="x"></i></button>
                    </span>
                </li>`;
        }).join('');
    }

    // Selector: solo las estaciones que todavía no están en este recorrido
    const enRecorrido = new Set(ed.estaciones);
    const disponibles = red.estaciones.filter(e => !enRecorrido.has(e.id));
    const select = redEl('lineaAgregar');
    select.innerHTML = '<option value="">Elegir estación…</option>'
        + disponibles.map(e => `<option value="${e.id}">${escaparHtml(e.nombre)}</option>`).join('');

    const etiqueta = redEl('lineaAgregarEtiqueta');
    if (ed.insertarDespues === null) {
        etiqueta.textContent = 'Agregar estación al final';
    } else {
        const previa = porId.get(ed.estaciones[ed.insertarDespues]);
        etiqueta.textContent = `Agregar estación después de «${previa ? previa.nombre : '…'}»`;
    }

    if (window.lucide) lucide.createIcons();
}

function manejarAccionRecorrido(e) {
    const boton = e.target.closest('button[data-accion]');
    const fila = e.target.closest('li[data-i]');
    if (!boton || !fila || !redEditor || redEditor.clase !== 'linea') return;

    const ed = redEditor;
    const i = Number(fila.dataset.i);

    switch (boton.dataset.accion) {
        case 'despues': // alterna el punto donde se insertará la próxima estación
            ed.insertarDespues = ed.insertarDespues === i ? null : i;
            break;
        case 'subir':
            if (i > 0) [ed.estaciones[i - 1], ed.estaciones[i]] = [ed.estaciones[i], ed.estaciones[i - 1]];
            ed.insertarDespues = null;
            break;
        case 'bajar':
            if (i < ed.estaciones.length - 1) [ed.estaciones[i + 1], ed.estaciones[i]] = [ed.estaciones[i], ed.estaciones[i + 1]];
            ed.insertarDespues = null;
            break;
        case 'quitar':
            ed.estaciones.splice(i, 1);
            ed.insertarDespues = null;
            break;
    }
    renderizarRecorrido();
    redibujarMapa();
}

function agregarEstacionAlRecorrido(id) {
    const ed = redEditor;
    if (!ed || ed.clase !== 'linea' || ed.estaciones.includes(id)) return;

    const posicion = ed.insertarDespues === null ? ed.estaciones.length : ed.insertarDespues + 1;
    ed.estaciones.splice(posicion, 0, id);
    // Si se estaba insertando "después de X", la siguiente va justo después de la que acaba de entrar
    if (ed.insertarDespues !== null) ed.insertarDespues = posicion;

    renderizarRecorrido();
    redibujarMapa();
}

async function guardarLineaRed() {
    const ed = redEditor;
    if (!ed || ed.clase !== 'linea') return;

    const nombre = ed.nombre.trim();
    if (!nombre) { mostrarToastAdmin('Escribe el nombre de la línea.'); return; }
    if (ed.estaciones.length < 2) { mostrarToastAdmin('El recorrido necesita al menos 2 estaciones.'); return; }

    const btn = redEl('btnGuardarLinea');
    btn.disabled = true;
    const data = await llamarAdminRed({
        accion: 'guardar_linea',
        clave: ed.clave,
        nombre,
        tipo: ed.tipoTransporte,
        color: ed.color,
        estaciones: ed.estaciones
    });
    btn.disabled = false;

    if (!data.exito) { mostrarToastAdmin(data.mensaje || 'No se pudo guardar la línea.'); return; }

    mostrarToastAdmin('Línea guardada. Los usuarios ya ven el cambio.');
    redEditor = null;
    await cargarRedAdmin();
    mostrarListasRed();
    actualizarHintMapa();
}

async function eliminarLineaRed() {
    const ed = redEditor;
    if (!ed || ed.clase !== 'linea' || !ed.clave) return;
    if (!confirm(`¿Eliminar la línea «${ed.nombre}»?\n\nLas estaciones no se borran; solo deja de existir esta línea.`)) return;

    const data = await llamarAdminRed({ accion: 'eliminar_linea', clave: ed.clave });
    if (!data.exito) { mostrarToastAdmin(data.mensaje || 'No se pudo eliminar la línea.'); return; }

    mostrarToastAdmin('Línea eliminada.');
    redEditor = null;
    await cargarRedAdmin();
    mostrarListasRed();
    actualizarHintMapa();
}

/* ---------- Editor de estación ---------- */
function abrirEditorEstacion(id) {
    const e = id ? red.estaciones.find(x => x.id === id) : null;
    if (id && !e) return;

    let lat = e ? e.lat : null;
    let lon = e ? e.lon : null;
    if (!e && red.mapa) { // estación nueva: el punto arranca en el centro del mapa para poder arrastrarlo
        const c = red.mapa.getCenter();
        lat = Number(c.lat.toFixed(6));
        lon = Number(c.lng.toFixed(6));
    }

    redEditor = { clase: 'estacion', id: e ? e.id : null, nombre: e ? e.nombre : '', dir: e ? e.dir : '', lat, lon };

    redEl('redTituloEstacion').textContent = e ? 'Editar estación' : 'Nueva estación';
    redEl('estacionNombre').value = redEditor.nombre;
    redEl('estacionDir').value = redEditor.dir;
    redEl('estacionLat').value = lat ?? '';
    redEl('estacionLon').value = lon ?? '';
    redEl('btnEliminarEstacion').hidden = !e;

    const ls = e ? lineasDeEstacion(e.id) : [];
    redEl('redEstacionLineas').textContent = !e
        ? 'Después de crearla, agrégala al recorrido de una línea desde la pestaña Líneas.'
        : ls.length
            ? 'Está en: ' + ls.map(l => l.nombre).join(', ') + '.'
            : 'Todavía no pertenece a ninguna línea. Agrégala desde la pestaña Líneas.';

    mostrarVistaEditor('estacion');
    actualizarHintMapa();
    redibujarMapa();
    if (red.mapa && e) red.mapa.setView([e.lat, e.lon], Math.max(red.mapa.getZoom(), 14));
    if (window.lucide) lucide.createIcons();
}

// Fija lat/lon de la estación en edición (clic en el mapa, arrastre o campos numéricos)
function ubicarEstacionEditada(lat, lon, redibujar) {
    const ed = redEditor;
    if (!ed || ed.clase !== 'estacion') return;
    ed.lat = Number(lat.toFixed(6));
    ed.lon = Number(lon.toFixed(6));
    redEl('estacionLat').value = ed.lat;
    redEl('estacionLon').value = ed.lon;
    if (redibujar) redibujarMapa();
}

async function guardarEstacionRed() {
    const ed = redEditor;
    if (!ed || ed.clase !== 'estacion') return;

    const nombre = ed.nombre.trim();
    if (!nombre) { mostrarToastAdmin('Escribe el nombre de la estación.'); return; }
    if (ed.lat === null || ed.lon === null || Number.isNaN(ed.lat) || Number.isNaN(ed.lon)) {
        mostrarToastAdmin('Marca la ubicación de la estación en el mapa.');
        return;
    }

    const btn = redEl('btnGuardarEstacion');
    btn.disabled = true;
    const data = await llamarAdminRed({
        accion: 'guardar_estacion',
        id: ed.id,
        nombre,
        dir: ed.dir.trim(),
        lat: ed.lat,
        lon: ed.lon
    });
    btn.disabled = false;

    if (!data.exito) { mostrarToastAdmin(data.mensaje || 'No se pudo guardar la estación.'); return; }

    mostrarToastAdmin('Estación guardada. Los usuarios ya ven el cambio.');
    redEditor = null;
    await cargarRedAdmin();
    mostrarListasRed();
    actualizarHintMapa();
}

async function eliminarEstacionRed() {
    const ed = redEditor;
    if (!ed || ed.clase !== 'estacion' || !ed.id) return;

    const ls = lineasDeEstacion(ed.id);
    const aviso = ls.length
        ? `\n\nSe quitará también del recorrido de: ${ls.map(l => l.nombre).join(', ')}.`
        : '';
    if (!confirm(`¿Eliminar la estación «${ed.nombre}»?${aviso}`)) return;

    const data = await llamarAdminRed({ accion: 'eliminar_estacion', id: ed.id });
    if (!data.exito) { mostrarToastAdmin(data.mensaje || 'No se pudo eliminar la estación.'); return; }

    mostrarToastAdmin('Estación eliminada.');
    redEditor = null;
    await cargarRedAdmin();
    mostrarListasRed();
    actualizarHintMapa();
}

/* ---------- Mapa ---------- */
function ajustarMapaAEstaciones(ids) {
    if (!red.mapa) return;
    const porId = estacionesPorId();
    const puntos = ids.map(id => porId.get(id)).filter(Boolean).map(e => [e.lat, e.lon]);
    if (puntos.length >= 2) red.mapa.fitBounds(L.latLngBounds(puntos), { padding: [50, 50] });
    else if (puntos.length === 1) red.mapa.setView(puntos[0], 15);
}

function redibujarMapa() {
    if (!red.mapa) return;
    if (red.capa) red.capa.remove();

    const capa = L.layerGroup();
    const ed = redEditor;
    const editandoLinea = !!ed && ed.clase === 'linea';
    const editandoEstacion = !!ed && ed.clase === 'estacion';
    const porId = estacionesPorId();

    // Líneas guardadas (la que se está editando se dibuja aparte, con sus cambios)
    red.lineas.forEach(l => {
        if (editandoLinea && ed.clave === l.clave) return;
        const puntos = l.estaciones.map(id => porId.get(id)).filter(Boolean).map(e => [e.lat, e.lon]);
        if (puntos.length < 2) return;
        L.polyline(puntos, {
            color: l.color,
            weight: 4,
            opacity: editandoLinea ? 0.25 : 0.85,
            dashArray: TRAZO_POR_TIPO[l.tipo] || null
        }).addTo(capa);
    });

    // Borrador de la línea en edición: trazo grueso y estaciones numeradas
    if (editandoLinea) {
        const est = ed.estaciones.map(id => porId.get(id)).filter(Boolean);
        if (est.length >= 2) {
            L.polyline(est.map(e => [e.lat, e.lon]), {
                color: ed.color,
                weight: 6,
                opacity: 0.95,
                dashArray: TRAZO_POR_TIPO[ed.tipoTransporte] || null
            }).addTo(capa);
        }
        est.forEach((e, i) => {
            L.circleMarker([e.lat, e.lon], {
                radius: 7, weight: 3, color: '#ffffff', fillColor: ed.color, fillOpacity: 1,
                bubblingMouseEvents: false
            }).bindTooltip(`${i + 1}. ${escaparHtml(e.nombre)}`, { direction: 'top', offset: [0, -6] }).addTo(capa);
        });
    }

    // Demás estaciones
    red.estaciones.forEach(e => {
        if (editandoEstacion && ed.id === e.id) return;          // en su lugar va el punto verde
        if (editandoLinea && ed.estaciones.includes(e.id)) return; // ya se dibujó numerada

        const ls = lineasDeEstacion(e.id);
        const color = ls.length === 0 ? '#94a3b8' : ls.length > 1 ? '#0f172a' : ls[0].color;
        const marcador = L.circleMarker([e.lat, e.lon], {
            radius: ls.length > 1 ? 7 : 5,
            weight: 2,
            color: '#ffffff',
            fillColor: color,
            fillOpacity: editandoLinea ? 0.45 : 1,
            bubblingMouseEvents: false // un clic en la estación no debe contar como clic en el mapa
        }).bindTooltip(
            escaparHtml(e.nombre) + (ls.length > 1 ? ' (transbordo)' : ls.length === 0 ? ' (sin línea)' : ''),
            { direction: 'top', offset: [0, -6] }
        );
        if (!editandoLinea) marcador.on('click', () => abrirEditorEstacion(e.id));
        marcador.addTo(capa);
    });

    // Punto verde de la estación en edición (se puede arrastrar)
    if (editandoEstacion && ed.lat !== null && ed.lon !== null) {
        const pin = L.marker([ed.lat, ed.lon], {
            draggable: true,
            icon: L.divIcon({ className: '', html: '<span class="red-pin"></span>', iconSize: [22, 22], iconAnchor: [11, 11] })
        });
        // No se redibuja al soltar: recrear el punto en pleno arrastre lo interrumpe.
        pin.on('dragend', () => {
            const p = pin.getLatLng();
            ubicarEstacionEditada(p.lat, p.lng, false);
        });
        pin.addTo(capa);
    }

    capa.addTo(red.mapa);
    red.capa = capa;
}

/* ---------- Conexión de los controles (una sola vez al cargar) ---------- */
function configurarEditorRed() {
    if (!redEl('view-estaciones')) return;

    document.querySelectorAll('.red-tab').forEach(b => {
        b.addEventListener('click', () => cambiarPestanaRed(b.dataset.redTab));
    });

    redEl('redListaLineas').addEventListener('click', (e) => {
        const item = e.target.closest('.red-item[data-clave]');
        if (item) abrirEditorLinea(item.dataset.clave);
    });
    redEl('redListaEstaciones').addEventListener('click', (e) => {
        const item = e.target.closest('.red-item[data-id]');
        if (item) abrirEditorEstacion(Number(item.dataset.id));
    });
    redEl('redBuscarEstacion').addEventListener('input', renderizarListaEstaciones);

    redEl('btnNuevaLinea').addEventListener('click', () => abrirEditorLinea(null));
    redEl('btnNuevaEstacion').addEventListener('click', () => abrirEditorEstacion(null));
    redEl('btnVolverLinea').addEventListener('click', cerrarEditorRed);
    redEl('btnVolverEstacion').addEventListener('click', cerrarEditorRed);

    // Línea
    redEl('lineaNombre').addEventListener('input', (e) => {
        if (redEditor && redEditor.clase === 'linea') redEditor.nombre = e.target.value;
    });
    redEl('lineaTipo').addEventListener('change', (e) => {
        if (redEditor && redEditor.clase === 'linea') { redEditor.tipoTransporte = e.target.value; redibujarMapa(); }
    });
    redEl('lineaColor').addEventListener('input', (e) => {
        if (redEditor && redEditor.clase === 'linea') {
            redEditor.color = e.target.value;
            renderizarRecorrido();
            redibujarMapa();
        }
    });
    redEl('redRecorrido').addEventListener('click', manejarAccionRecorrido);
    redEl('lineaAgregar').addEventListener('change', (e) => {
        const id = Number(e.target.value);
        if (id) agregarEstacionAlRecorrido(id);
    });
    redEl('btnGuardarLinea').addEventListener('click', guardarLineaRed);
    redEl('btnEliminarLinea').addEventListener('click', eliminarLineaRed);

    // Estación
    redEl('estacionNombre').addEventListener('input', (e) => {
        if (redEditor && redEditor.clase === 'estacion') redEditor.nombre = e.target.value;
    });
    redEl('estacionDir').addEventListener('input', (e) => {
        if (redEditor && redEditor.clase === 'estacion') redEditor.dir = e.target.value;
    });
    ['estacionLat', 'estacionLon'].forEach(id => {
        redEl(id).addEventListener('change', () => {
            if (!redEditor || redEditor.clase !== 'estacion') return;
            const lat = parseFloat(redEl('estacionLat').value);
            const lon = parseFloat(redEl('estacionLon').value);
            if (Number.isNaN(lat) || Number.isNaN(lon)) return;
            ubicarEstacionEditada(lat, lon, true);
            if (red.mapa) red.mapa.panTo([redEditor.lat, redEditor.lon]);
        });
    });
    redEl('btnGuardarEstacion').addEventListener('click', guardarEstacionRed);
    redEl('btnEliminarEstacion').addEventListener('click', eliminarEstacionRed);
}
