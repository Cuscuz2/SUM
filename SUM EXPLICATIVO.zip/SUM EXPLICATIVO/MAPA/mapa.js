/* =====================================================================
   SUM — Sistema de Ubicación Metro · MAPA/mapa.js
   Lógica de la aplicación principal (mapa.html): es lo que ve el usuario
   después de iniciar sesión.

   SECCIONES DEL ARCHIVO (en orden)
   - Arranque y navegación entre vistas (Usuario, Panel, Historial, Config., Soporte)
   - Mapa Leaflet y datos de la red (estaciones y líneas)
   - Carga de la red desde la base de datos (red.php) con copia de respaldo
   - Dibujo de la red, leyenda y controles del mapa
   - Tarifas, avisos del administrador y verificación de sesión
   - Acceso de administrador (modal con contraseña)
   - Historial de viajes y perfil de usuario
   - Buscador de estaciones (autocompletado)
   - Cálculo de ruta: grafo + búsqueda BFS + transbordos + tarifa + tiempo
   - Indicaciones paso a paso y mensajes flotantes (toast)

   FLUJO PRINCIPAL PARA EXPONER
   El usuario elige origen y destino → buscarEstacion() → encontrarRutaOptima()
   (búsqueda BFS sobre un grafo de estaciones) → se dibuja la ruta y se estima
   tiempo y costo → al pulsar 'Iniciar Navegación' el viaje se guarda en la
   base de datos (registrar_viaje.php) y aparece en el Historial.

   COMUNICACIÓN CON EL SERVIDOR
   Todas las llamadas usan fetch() hacia ../PHP/ con credentials: 'same-origin',
   que envía la cookie de sesión de PHP para saber quién es el usuario.
   ===================================================================== */

// mapa.js — Proyecto SUM (Sistema de Ubicación Metro)
// Incluye: Mapa Interactivo, Navegación de Vistas, Historial de Viajes,
// y Buscador de estaciones agrupado por línea con dirección exacta.
//
// Cobertura de red: Metro (Línea A y B), Metrocable (K, J, H, L),
// Tranvía de Ayacucho (T-A) y Metroplús (Línea 1 y 2).
// Coordenadas: feed GTFS oficial del Metro de Medellín (ColombiaInfo/ColombiaGTFS).
// Direcciones: Metro de Medellín (metrodemedellin.gov.co) y Wikipedia
// ("Anexo:Estaciones del Metro de Medellín"). Las direcciones marcadas con
// "(aprox.)" no tienen una nomenclatura oficial publicada (paradas de tranvía,
// metrocable o estaciones de Metroplús sin dirección catastral verificada) y
// se calculan a partir de la vía/cruce donde se ubica la estación; se
// recomienda verificarlas en el sitio oficial antes de usarlas como destino
// postal.

const MEDELLIN_CENTRO = [6.2472, -75.5697]; // San Antonio: corazón del sistema

// Variables globales del mapa: la instancia de Leaflet, las dos capas base (clara y
// estándar), los marcadores de origen, destino y ubicación, y la línea de la ruta.
let mapa, capaClara, capaEstandar, capaActual = 'clara';
let marcadorOrigen, marcadorDestino, marcadorUbicacion, lineaRuta;

// capasMetro guarda un grupo de capas por categoría de la leyenda, para poder mostrarlas
// u ocultarlas con los botones.
const capasMetro = {};

// ⚠️ Clave API de CARTO Basemaps
// SEGURIDAD: esta clave queda visible en el navegador (cualquiera puede verla en el
// código). Es lo normal en mapas del lado del cliente, pero conviene restringirla por
// dominio desde el panel del proveedor.
const CARTO_API_KEY = 'cb1_2883_1_32f0bf1288bfd12fd81c1134';

// ARRANQUE: cuando el HTML termina de cargar se ejecuta, en orden: 1) carga la red desde
// la BD, 2) crea el mapa y dibuja las líneas, 3) conecta los botones y 4) consulta los
// datos del usuario (perfil, tarifas, avisos y sesión).
document.addEventListener('DOMContentLoaded', async () => {
    if (window.lucide) lucide.createIcons();

    // La red (líneas y estaciones) la administra el admin desde su panel y se
    // lee de la base de datos. Si el servidor no responde, se usa la copia
    // escrita más abajo en este archivo, para que el mapa nunca quede vacío.
    await cargarRedDesdeServidor();

    inicializarMapa();
    dibujarRedCompleta();

    configurarZoom();
    configurarUbicacion();
    configurarCapas();
    configurarSwap();
    configurarNavegar();
    configurarLeyenda();
    configurarEnter();
    configurarAutocompletado();
    configurarCambioTarifa();
    configurarUsuario();
    configurarAdminAccess();

    // Navegación entre pestañas (Panel, Historial, Configuración, Soporte)
    configurarNavegacionMenu();

    // Mini-perfil de la barra lateral (foto + nombre)
    cargarPerfil();

    // Tarifas reales (las administra el admin desde su panel)
    cargarTarifas();

    // Avisos del administrador
    configurarAvisos();

    // Si el admin suspende esta cuenta mientras la persona sigue navegando,
    // esto la detecta y la saca del sistema al instante.
    configurarVerificacionSesion();

    // Ruta inicial
    calcularRuta();
});

/* ---------- Cambiar entre Vistas / Pestañas ---------- */
// Vistas tipo pestañas: el HTML tiene 5 bloques .dash-view y solo uno tiene la clase
// 'active'. Al hacer clic en el menú se mueve esa clase. El mapa necesita
// invalidateSize() al volver porque estaba oculto y Leaflet pierde sus medidas.
function configurarNavegacionMenu() {
    const navItems = document.querySelectorAll('.dash-nav-item');
    const views = document.querySelectorAll('.dash-view');

    function cambiarVista(targetId) {
        if (!targetId) return;

        views.forEach(v => v.classList.remove('active'));

        const targetView = document.getElementById(targetId);
        if (targetView) {
            targetView.classList.add('active');

            navItems.forEach(item => {
                if (item.getAttribute('data-target') === targetId) {
                    item.classList.add('active');
                } else {
                    item.classList.remove('active');
                }
            });

            if (targetId === 'view-dashboard' && mapa) {
                setTimeout(() => mapa.invalidateSize(), 150);
            }

            if (targetId === 'view-history') {
                cargarHistorial();
            }

            if (targetId === 'view-profile') {
                cargarPerfil();
            }

            if (window.lucide) lucide.createIcons();
        }
    }

    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            const target = item.getAttribute('data-target');
            if (target) {
                e.preventDefault();
                cambiarVista(target);
            }
        });
    });
}

/* ---------- Mapa Leaflet ---------- */
// Crea el mapa Leaflet centrado en San Antonio. Hay dos capas base: la clara (CARTO) y
// la estándar (OpenStreetMap); el botón de capas alterna entre ellas.
function inicializarMapa() {
    mapa = L.map('leafletMap', {
        zoomControl: false,
        attributionControl: true
    }).setView(MEDELLIN_CENTRO, 12);

    capaClara = L.tileLayer('https://basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png?key=' + CARTO_API_KEY, {
        attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
        subdomains: 'abcd',
        maxZoom: 20
    }).addTo(mapa);

    capaEstandar = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19
    });

    setTimeout(() => mapa.invalidateSize(), 200);
}

/* =========================================================
   RED COMPLETA DEL SISTEMA (datos reales, fuente GTFS oficial)
   Cada estación incluye "dir": la dirección de acceso a la estación.
   ========================================================= */

// NOTA: estos arreglos son la COPIA DE RESPALDO de la red. Si el servidor responde
// (red.php), se reemplazan por lo que el administrador configuró en la base de datos.
// Cada estación tiene nombre, lat/lon (coordenadas) y dir (dirección).
// Metro — Línea A (Niquía ↔ La Estrella)
const ESTACIONES_A = [
    { nombre: 'Niquía', lat: 6.33788, lon: -75.54433, dir: 'Diagonal 50A # 37-01, Bello' },
    { nombre: 'Bello', lat: 6.32989, lon: -75.55375, dir: 'Calle 44 # 46-001, Bello' },
    { nombre: 'Madera', lat: 6.31603, lon: -75.55534, dir: 'Carrera 49 # 25B-20, Bello' },
    { nombre: 'Acevedo', lat: 6.29986, lon: -75.55853, dir: 'Carrera 63 # 103G-202 (acceso norte), Medellín' },
    { nombre: 'Tricentenario', lat: 6.29031, lon: -75.56473, dir: 'Carrera 63 # 94A-518 (acceso norte), Medellín' },
    { nombre: 'Caribe', lat: 6.27828, lon: -75.56937, dir: 'Carrera 64 # 75B-600 (acceso norte), Medellín' },
    { nombre: 'Universidad', lat: 6.26933, lon: -75.56577, dir: 'Calle 73 # 52-40, Medellín' },
    { nombre: 'Hospital', lat: 6.26368, lon: -75.56344, dir: 'Carrera 51 # 65-85, Medellín' },
    { nombre: 'Prado', lat: 6.25679, lon: -75.56605, dir: 'Carrera 51D # 57-100, Medellín' },
    { nombre: 'Parque Berrío', lat: 6.25054, lon: -75.56828, dir: 'Carrera 51 con Calle 50 (aprox.), Medellín' },
    { nombre: 'San Antonio', lat: 6.24707, lon: -75.56969, dir: 'Carrera 51 con Calle 46, Medellín' },
    { nombre: 'Alpujarra', lat: 6.24292, lon: -75.57136, dir: 'Carrera 51 # 41-43, Medellín' },
    { nombre: 'Exposiciones', lat: 6.23843, lon: -75.57322, dir: 'Carrera 51 con Calle 37, Medellín' },
    { nombre: 'Industriales', lat: 6.23002, lon: -75.57561, dir: 'Carrera 49 # 24-435, Medellín' },
    { nombre: 'Poblado', lat: 6.21196, lon: -75.57806, dir: 'Avenida El Poblado, sector Astorga (aprox.), Medellín' },
    { nombre: 'Aguacatala', lat: 6.19377, lon: -75.58192, dir: 'Carrera 48C # 12 Sur-50, Medellín' },
    { nombre: 'Ayurá', lat: 6.18601, lon: -75.5862, dir: 'Avenida Regional con Calle 32 Sur (aprox.), Envigado' },
    { nombre: 'Envigado', lat: 6.17469, lon: -75.59706, dir: 'Carrera 42 # 59A-291, Envigado' },
    { nombre: 'Itagüí', lat: 6.16296, lon: -75.60671, dir: 'Carrera 49 # 50 Sur-80, Itagüí' },
    { nombre: 'Sabaneta', lat: 6.15789, lon: -75.61604, dir: 'Carrera 49 # 67 Sur, Sabaneta' },
    { nombre: 'La Estrella', lat: 6.15263, lon: -75.62646, dir: 'Carrera 49 # 77 Sur, La Estrella' }
];

// Metro — Línea B (San Antonio ↔ San Javier)
const ESTACIONES_B = [
    { nombre: 'San Antonio', lat: 6.24715, lon: -75.56968, dir: 'Carrera 51 con Calle 46, Medellín' },
    { nombre: 'Cisneros', lat: 6.24901, lon: -75.57511, dir: 'Carrera 57 # 45A-50, Medellín' },
    { nombre: 'Suramericana', lat: 6.253, lon: -75.58302, dir: 'Carrera 65 con Calle 44 (aprox.), Medellín' },
    { nombre: 'Estadio', lat: 6.25332, lon: -75.58824, dir: 'Carrera 70 # 47D-15, Medellín' },
    { nombre: 'Floresta', lat: 6.2587, lon: -75.5977, dir: 'Carrera 80 # 47D-30, Medellín' },
    { nombre: 'Santa Lucía', lat: 6.25806, lon: -75.60377, dir: 'Calle 47DD # 86-53, Medellín' },
    { nombre: 'San Javier', lat: 6.25686, lon: -75.61378, dir: 'Carrera 99 # 45-26, Medellín' }
];

// Tranvía de Ayacucho (San Antonio ↔ Oriente) — con todas las estaciones intermedias
const ESTACIONES_TRANVIA = [
    { nombre: 'San Antonio', lat: 6.247, lon: -75.56913, dir: 'Carrera 51 con Calle 46, Medellín' },
    { nombre: 'San José', lat: 6.24737, lon: -75.5655, dir: 'Avenida Oriental con Calle 49 (aprox.), Medellín' },
    { nombre: 'Pabellón del Agua', lat: 6.24555, lon: -75.56182, dir: 'Avenida Ayacucho, barrio Barrio Colón (aprox.), Medellín' },
    { nombre: 'Bicentenario', lat: 6.24386, lon: -75.55853, dir: 'Avenida Ayacucho, barrio Boston (aprox.), Medellín' },
    { nombre: 'Buenos Aires', lat: 6.2415, lon: -75.55389, dir: 'Avenida Ayacucho con Carrera 29 (aprox.), Medellín' },
    { nombre: 'Miraflores', lat: 6.24148, lon: -75.54907, dir: 'Avenida Ayacucho, barrio Miraflores (aprox.), Medellín' },
    { nombre: 'Loyola', lat: 6.23924, lon: -75.54524, dir: 'Avenida Ayacucho, barrio Loyola (aprox.), Medellín' },
    { nombre: 'Alejandro Echavarría', lat: 6.2354, lon: -75.54153, dir: 'Barrio Alejandro Echavarría (aprox.), Medellín' },
    { nombre: 'Oriente', lat: 6.23304, lon: -75.54001, dir: 'Barrio Oriente, comuna 8 (aprox.), Medellín' }
];

// Metrocable — Línea K (Acevedo ↔ Santo Domingo)
const ESTACIONES_K = [
    { nombre: 'Acevedo', lat: 6.30025, lon: -75.55827, dir: 'Carrera 63 # 103G-202 (acceso norte), Medellín' },
    { nombre: 'Andalucía', lat: 6.29618, lon: -75.55193, dir: 'Carrera 46A # 107-3, Medellín' },
    { nombre: 'Popular', lat: 6.29513, lon: -75.54815, dir: 'Carrera 42B # 107-61, Medellín' },
    { nombre: 'Santo Domingo', lat: 6.29316, lon: -75.54172, dir: 'Carrera 51A # 46-08, Medellín' }
];

// Metrocable — Línea L (Santo Domingo ↔ Arví)
const ESTACIONES_L = [
    { nombre: 'Santo Domingo', lat: 6.29274, lon: -75.5419, dir: 'Carrera 51A # 46-08, Medellín' },
    { nombre: 'Arví', lat: 6.28153, lon: -75.50293, dir: 'Parque Arví, vereda Piedras Blancas, Santa Elena (aprox.), Medellín' }
];

// Metrocable — Línea P / Metrocable Picacho (Acevedo ↔ El Progreso), inaugurada el 10 de junio de 2021.
// Recorre las comunas 5 (Castilla) y 6 (Doce de Octubre) hasta el Cerro El Picacho, en límites con Bello.
const ESTACIONES_P = [
    { nombre: 'Acevedo', lat: 6.30028, lon: -75.55847, dir: 'Carrera 63 # 103G-202 (acceso norte), Medellín' },
    { nombre: 'Sena', lat: 6.30168, lon: -75.56648, dir: 'Calle 104 # 67-32, barrio Pedregal (Castilla), Medellín' },
    { nombre: 'Doce de Octubre', lat: 6.30309, lon: -75.57449, dir: 'Barrio Doce de Octubre, comuna 6 (aprox.), Medellín' },
    { nombre: 'El Progreso', lat: 6.30449, lon: -75.58251, dir: 'Carrera 83A con Calle 104C (aprox.), junto al Cerro El Picacho, Bello' }
];

// Metrocable — Línea H (Oriente ↔ Villa Sierra)
const ESTACIONES_H = [
    { nombre: 'Oriente', lat: 6.2332, lon: -75.54, dir: 'Barrio Oriente, comuna 8 (aprox.), Medellín' },
    { nombre: 'Las Torres', lat: 6.23655, lon: -75.53628, dir: 'Barrio Las Torres, comuna 8 (aprox.), Medellín' },
    { nombre: 'Villa Sierra', lat: 6.23499, lon: -75.52864, dir: 'Barrio La Sierra, comuna 8 (aprox.), Medellín' }
];

// Metrocable — Línea J (San Javier ↔ La Aurora)
const ESTACIONES_J = [
    { nombre: 'San Javier', lat: 6.25679, lon: -75.61341, dir: 'Carrera 99 # 45-26, Medellín' },
    { nombre: 'Juan XXIII', lat: 6.26569, lon: -75.61369, dir: 'Carrera 99CD con Calle 48B, Medellín' },
    { nombre: 'Vallejuelos', lat: 6.27538, lon: -75.61402, dir: 'Calle 61B con Carrera 104, Medellín' },
    { nombre: 'La Aurora', lat: 6.2811, lon: -75.61421, dir: 'Calle 64 con Carrera 104, Medellín' }
];

// Metroplús — Línea 1 (Universidad de Medellín ↔ Parque de Aranjuez, por Av. Ferrocarril)
const ESTACIONES_MP1 = [
    { nombre: 'U. de M.', lat: 6.2306, lon: -75.60913, dir: 'Carrera 87B con Calle 30A, Medellín' },
    { nombre: 'Los Alpes', lat: 6.23103, lon: -75.60506, dir: 'Carrera 84 con Calle 30A, Medellín' },
    { nombre: 'La Palma', lat: 6.2311, lon: -75.60106, dir: 'Carrera 81 con Calle 30A, Medellín' },
    { nombre: 'Parque Belén', lat: 6.23133, lon: -75.59675, dir: 'Carrera 76 con Calle 30A, Medellín' },
    { nombre: 'Rosales', lat: 6.23153, lon: -75.59096, dir: 'Carrera 73 con Calle 30A, Medellín' },
    { nombre: 'Fátima', lat: 6.2316, lon: -75.58655, dir: 'Carrera 70 con Calle 30A, Medellín' },
    { nombre: 'Nutibara', lat: 6.23171, lon: -75.58206, dir: 'Carrera 65 con Avenida 33, Medellín' },
    { nombre: 'Industriales', lat: 6.23022, lon: -75.57652, dir: 'Avenida Ferrocarril con Calle 30, Medellín' },
    { nombre: 'Plaza Mayor', lat: 6.2437, lon: -75.57529, dir: 'Calle 41 con Carrera 52 (aprox.), Medellín' },
    { nombre: 'Cisneros', lat: 6.24874, lon: -75.57503, dir: 'Carrera 57 # 45A-50, Medellín' },
    { nombre: 'Minorista', lat: 6.2561, lon: -75.57312, dir: 'Carrera 57 # 54-01, Medellín' },
    { nombre: 'Chagualo', lat: 6.26073, lon: -75.56913, dir: 'Carrera 55 con Calle 65 (aprox.), Medellín' },
    { nombre: 'Ruta N - U. de A.', lat: 6.26355, lon: -75.56764, dir: 'Carrera 55 # 65-01, Medellín' },
    { nombre: 'Hospital', lat: 6.26383, lon: -75.56313, dir: 'Carrera 51 # 65-85, Medellín' },
    { nombre: 'San Pedro', lat: 6.26339, lon: -75.56017, dir: 'Carrera 51 con Calle 68 (aprox.), Medellín' }, // fuera de servicio operativo actualmente
    { nombre: 'Palos Verdes', lat: 6.26208, lon: -75.55581, dir: 'Carrera 45 # 66-01, Medellín' },
    { nombre: 'Gardel', lat: 6.26768, lon: -75.55495, dir: 'Carrera 45 con Calle 70 (aprox.), Medellín' },
    { nombre: 'Manrique', lat: 6.27322, lon: -75.55401, dir: 'Carrera 45 con Calle 73 (aprox.), Medellín' },
    { nombre: 'Las Esmeraldas', lat: 6.27838, lon: -75.55312, dir: 'Carrera 45 con Calle 78 (aprox.), Medellín' },
    { nombre: 'Berlín', lat: 6.28287, lon: -75.55285, dir: 'Carrera 45 con Calle 83 (aprox.), Medellín' },
    { nombre: 'Parque Aranjuez', lat: 6.28519, lon: -75.55663, dir: 'Carrera 49A # 93-00, Medellín' }
];

// Metroplús — Línea 2 (Universidad de Medellín ↔ Parque de Aranjuez, por Av. Oriental)
const ESTACIONES_MP2 = [
    { nombre: 'U. de M.', lat: 6.2306, lon: -75.60913, dir: 'Carrera 87B con Calle 30A, Medellín' },
    { nombre: 'Los Alpes', lat: 6.23103, lon: -75.60506, dir: 'Carrera 84 con Calle 30A, Medellín' },
    { nombre: 'La Palma', lat: 6.2311, lon: -75.60106, dir: 'Carrera 81 con Calle 30A, Medellín' },
    { nombre: 'Parque Belén', lat: 6.23133, lon: -75.59675, dir: 'Carrera 76 con Calle 30A, Medellín' },
    { nombre: 'Rosales', lat: 6.23153, lon: -75.59096, dir: 'Carrera 73 con Calle 30A, Medellín' },
    { nombre: 'Fátima', lat: 6.2316, lon: -75.58655, dir: 'Carrera 70 con Calle 30A, Medellín' },
    { nombre: 'Nutibara', lat: 6.23171, lon: -75.58206, dir: 'Carrera 65 con Avenida 33, Medellín' },
    { nombre: 'Industriales', lat: 6.23022, lon: -75.57652, dir: 'Avenida Ferrocarril con Calle 30, Medellín' },
    { nombre: 'Barrio Colombia', lat: 6.22864, lon: -75.571, dir: 'Carrera 52 con Calle 30 (aprox.), Medellín' },
    { nombre: 'Barrio San Diego', lat: 6.23358, lon: -75.57002, dir: 'Carrera 46 con Calle 34 (aprox.), Medellín' },
    { nombre: 'Barrio Colón', lat: 6.24057, lon: -75.56971, dir: 'Carrera 45 con Calle 44 (aprox.), Medellín' },
    { nombre: 'San José', lat: 6.24658, lon: -75.56644, dir: 'Avenida Oriental con Calle 49 (aprox.), Medellín' },
    { nombre: 'La Playa', lat: 6.24933, lon: -75.56446, dir: 'Carrera 45 con Avenida La Playa (aprox.), Medellín' },
    { nombre: 'Catedral Metropolitana', lat: 6.25293, lon: -75.56238, dir: 'Parque Bolívar (aprox.), Medellín' },
    { nombre: 'Prado', lat: 6.25783, lon: -75.56551, dir: 'Carrera 51 con Calle 57 (aprox.), Medellín' },
    { nombre: 'Hospital', lat: 6.26293, lon: -75.56356, dir: 'Carrera 51 # 65-85, Medellín' },
    { nombre: 'San Pedro', lat: 6.26339, lon: -75.56017, dir: 'Carrera 51 con Calle 68 (aprox.), Medellín' },
    { nombre: 'Palos Verdes', lat: 6.26208, lon: -75.55581, dir: 'Carrera 45 # 66-01, Medellín' },
    { nombre: 'Gardel', lat: 6.26768, lon: -75.55495, dir: 'Carrera 45 con Calle 70 (aprox.), Medellín' },
    { nombre: 'Manrique', lat: 6.27322, lon: -75.55401, dir: 'Carrera 45 con Calle 73 (aprox.), Medellín' },
    { nombre: 'Las Esmeraldas', lat: 6.27838, lon: -75.55312, dir: 'Carrera 45 con Calle 78 (aprox.), Medellín' },
    { nombre: 'Berlín', lat: 6.28287, lon: -75.55285, dir: 'Carrera 45 con Calle 83 (aprox.), Medellín' },
    { nombre: 'Parque Aranjuez', lat: 6.28519, lon: -75.55663, dir: 'Carrera 49A # 93-00, Medellín' }
];

// Definición de cada línea: color, tipo, estilo de trazo y categoría de leyenda
// LINEAS es el objeto central de la red. La clave es el id de la línea (a, b, k...) y
// cada una guarda sus estaciones, color, tipo de trazo (continuo o punteado) y categoría
// de leyenda. Casi todo el mapa se dibuja y se calcula a partir de este objeto.
let LINEAS = {
    a:       { estaciones: ESTACIONES_A,       color: '#2563eb', dash: null,     categoria: 'metro-a' },
    b:       { estaciones: ESTACIONES_B,       color: '#f5a623', dash: null,     categoria: 'metro-b' },
    k:       { estaciones: ESTACIONES_K,       color: '#0d9488', dash: '2 8',    categoria: 'metrocable' },
    l:       { estaciones: ESTACIONES_L,       color: '#0d9488', dash: '2 8',    categoria: 'metrocable' },
    p:       { estaciones: ESTACIONES_P,       color: '#0d9488', dash: '2 8',    categoria: 'metrocable' },
    h:       { estaciones: ESTACIONES_H,       color: '#0d9488', dash: '2 8',    categoria: 'metrocable' },
    j:       { estaciones: ESTACIONES_J,       color: '#0d9488', dash: '2 8',    categoria: 'metrocable' },
    mp1:     { estaciones: ESTACIONES_MP1,     color: '#e11d48', dash: '6 4',    categoria: 'metroplus' },
    mp2:     { estaciones: ESTACIONES_MP2,     color: '#e11d48', dash: '6 4',    categoria: 'metroplus' },
    tranvia: { estaciones: ESTACIONES_TRANVIA, color: '#7c3aed', dash: '2 8',    categoria: 'tranvia' }
};

// Categorías visibles en la leyenda del mapa (agrupan varias líneas si aplica)
let CATEGORIAS_LEYENDA = [
    { id: 'metro-a',    etiqueta: 'Línea A',    color: '#2563eb' },
    { id: 'metro-b',    etiqueta: 'Línea B',    color: '#f5a623' },
    { id: 'metrocable', etiqueta: 'Metrocable', color: '#0d9488' },
    { id: 'metroplus',  etiqueta: 'Metroplús',  color: '#e11d48' },
    { id: 'tranvia',    etiqueta: 'Tranvía',    color: '#7c3aed' }
];

// Etiquetas y orden de presentación de cada línea en el buscador de estaciones
let ETIQUETAS_LINEA = {
    a:       'Línea A · Metro',
    b:       'Línea B · Metro',
    tranvia: 'Tranvía de Ayacucho',
    k:       'Metrocable K',
    j:       'Metrocable J',
    h:       'Metrocable H',
    l:       'Metrocable L',
    p:       'Metrocable Picacho (P)',
    mp1:     'Metroplús · Línea 1',
    mp2:     'Metroplús · Línea 2'
};
let ORDEN_LINEAS = ['a', 'b', 'tranvia', 'k', 'j', 'h', 'l', 'p', 'mp1', 'mp2'];

/* ---------- Red desde la base de datos (PHP/red.php) ---------- */
// Los arreglos de arriba quedan como respaldo. Si red.php responde con al
// menos una línea, se reemplazan por lo que el administrador configuró.
// AbortController + setTimeout: si el servidor no responde en 5 segundos se cancela la
// petición y se usa la copia local, así el mapa nunca queda vacío. El JSON de red.php se
// convierte al mismo formato de LINEAS y se reconstruye el grafo de rutas.
async function cargarRedDesdeServidor() {
    const controlador = new AbortController();
    const temporizador = setTimeout(() => controlador.abort(), 5000);

    try {
        const res = await fetch(API_BASE + 'red.php', {
            credentials: 'same-origin',
            signal: controlador.signal
        });
        const data = await res.json();
        if (!data.exito || !Array.isArray(data.lineas) || !data.lineas.length) return false;

        const TRAZO = { metro: null, metrocable: '2 8', metroplus: '6 4', tranvia: '2 8' };
        const NOMBRE_TIPO = { metrocable: 'Metrocable', metroplus: 'Metroplús', tranvia: 'Tranvía' };

        const lineas = {};
        const categorias = [];
        const etiquetas = {};
        const orden = [];

        data.lineas.forEach(l => {
            const esMetro = l.tipo === 'metro';
            // Cada línea de Metro tiene su propio botón en la leyenda; el resto se agrupa por tipo.
            const categoria = esMetro ? 'metro-' + l.clave : l.tipo;

            lineas[l.clave] = {
                estaciones: l.estaciones,
                color: l.color,
                dash: TRAZO[l.tipo] ?? null,
                categoria
            };
            etiquetas[l.clave] = l.nombre;
            orden.push(l.clave);

            if (!categorias.some(c => c.id === categoria)) {
                categorias.push({
                    id: categoria,
                    etiqueta: esMetro ? l.nombre.split(' · ')[0] : (NOMBRE_TIPO[l.tipo] || l.nombre),
                    color: l.color
                });
            }
        });

        LINEAS = lineas;
        CATEGORIAS_LEYENDA = categorias;
        ETIQUETAS_LINEA = etiquetas;
        ORDEN_LINEAS = orden;
        construirGrafo();
        return true;
    } catch (err) {
        console.warn('No se pudo cargar la red desde el servidor; se usa la copia local:', err);
        return false;
    } finally {
        clearTimeout(temporizador);
    }
}

/* ---------- Etiqueta/color visual de cada línea (para las indicaciones) ---------- */
function infoDeLinea(claveLinea) {
    const linea = LINEAS[claveLinea];
    const cat = CATEGORIAS_LEYENDA.find(c => c.id === linea.categoria);
    return {
        etiqueta: cat ? cat.etiqueta : claveLinea.toUpperCase(),
        color: linea.color
    };
}

/* ---------- Estaciones únicas + detección de transbordos ---------- */
// Devuelve cada estación una sola vez (aunque esté en varias líneas). Se usa para buscar
// y para obtener coordenadas.
function listaEstacionesUnicas() {
    const vistas = new Map();
    Object.values(LINEAS).forEach(linea => {
        linea.estaciones.forEach(e => {
            if (!vistas.has(e.nombre)) vistas.set(e.nombre, e);
        });
    });
    return [...vistas.values()];
}

// Relaciona cada estación con las líneas que pasan por ella. Si pasan 2 o más, esa
// estación es un transbordo (se dibuja más grande y oscura).
function lineasPorEstacion() {
    const mapa = new Map(); // nombre -> Set(claveLinea)
    Object.entries(LINEAS).forEach(([clave, linea]) => {
        linea.estaciones.forEach(e => {
            if (!mapa.has(e.nombre)) mapa.set(e.nombre, new Set());
            mapa.get(e.nombre).add(clave);
        });
    });
    return mapa;
}

/* ---------- Dibujo de la red completa ---------- */
// Círculo de una estación con su tooltip (nombre y dirección). Los transbordos son más
// grandes y oscuros.
function crearMarcadorEstacion(estacion, color, esTransbordo) {
    const tooltipTexto = escaparHtmlMapa(estacion.nombre)
        + (esTransbordo ? ' (transbordo)' : '')
        + (estacion.dir ? `<br><span style="opacity:.75;font-weight:500;">${escaparHtmlMapa(estacion.dir)}</span>` : '');
    return L.circleMarker([estacion.lat, estacion.lon], {
        radius: esTransbordo ? 7 : 5,
        weight: esTransbordo ? 3 : 2,
        color: '#ffffff',
        fillColor: esTransbordo ? '#0f172a' : color,
        fillOpacity: 1
    }).bindTooltip(tooltipTexto, { direction: 'top', offset: [0, -6] });
}

// Dibuja cada línea como polilínea con sus estaciones y agrupa las capas por categoría
// de leyenda, para poder encenderlas y apagarlas.
function dibujarRedCompleta() {
    const transbordos = lineasPorEstacion();

    // Agrupar capas por categoría de leyenda (varias líneas pueden compartir categoría)
    const gruposPorCategoria = {};

    Object.values(LINEAS).forEach(linea => {
        const polilinea = L.polyline(linea.estaciones.map(e => [e.lat, e.lon]), {
            color: linea.color,
            weight: 4,
            opacity: 0.85,
            dashArray: linea.dash || null
        });

        const marcadores = linea.estaciones.map(e => {
            const esTransbordo = transbordos.get(e.nombre).size > 1;
            return crearMarcadorEstacion(e, linea.color, esTransbordo);
        });

        if (!gruposPorCategoria[linea.categoria]) gruposPorCategoria[linea.categoria] = [];
        gruposPorCategoria[linea.categoria].push(polilinea, ...marcadores);
    });

    Object.entries(gruposPorCategoria).forEach(([categoria, capas]) => {
        capasMetro[categoria] = L.layerGroup(capas).addTo(mapa);
    });
}

// Crea un botón por categoría; al hacer clic quita o agrega esa capa del mapa.
function configurarLeyenda() {
    const contenedor = document.querySelector('.map-legend');
    if (!contenedor) return;
    contenedor.innerHTML = '';

    CATEGORIAS_LEYENDA.forEach(cat => {
        const pill = document.createElement('button');
        pill.className = 'legend-pill';
        pill.type = 'button';
        pill.dataset.line = cat.id;
        pill.innerHTML = `<span class="legend-dot" style="background:${cat.color};"></span>${escaparHtmlMapa(cat.etiqueta)}`;
        pill.addEventListener('click', () => {
            const capa = capasMetro[cat.id];
            if (!capa) return;
            if (mapa.hasLayer(capa)) {
                mapa.removeLayer(capa);
                pill.classList.add('inactive');
            } else {
                capa.addTo(mapa);
                pill.classList.remove('inactive');
            }
        });
        contenedor.appendChild(pill);
    });
}

/* ---------- Zoom y Ubicación ---------- */
function configurarZoom() {
    document.getElementById('btnZoomIn').addEventListener('click', () => mapa.zoomIn());
    document.getElementById('btnZoomOut').addEventListener('click', () => mapa.zoomOut());
}

// Geolocalización del navegador (pide permiso al usuario): coloca un punto en su
// posición y centra el mapa.
function configurarUbicacion() {
    document.getElementById('btnLocate').addEventListener('click', () => {
        if (!navigator.geolocation) {
            mostrarToast('Geolocalización no soportada.');
            return;
        }
        mostrarToast('Obteniendo ubicación…');
        navigator.geolocation.getCurrentPosition(
            (pos) => {
                const { latitude, longitude } = pos.coords;
                if (marcadorUbicacion) mapa.removeLayer(marcadorUbicacion);
                marcadorUbicacion = L.marker([latitude, longitude], {
                    icon: L.divIcon({
                        className: '',
                        html: '<span class="geo-marker"></span>',
                        iconSize: [16, 16],
                        iconAnchor: [8, 8]
                    })
                }).addTo(mapa);
                mapa.setView([latitude, longitude], 15);
                mostrarToast('Ubicación encontrada');
            },
            () => mostrarToast('No se pudo obtener tu ubicación'),
            { enableHighAccuracy: true, timeout: 8000 }
        );
    });
}

function configurarCapas() {
    document.getElementById('btnLayers').addEventListener('click', () => {
        if (capaActual === 'clara') {
            mapa.removeLayer(capaClara);
            capaEstandar.addTo(mapa);
            capaActual = 'estandar';
            mostrarToast('Mapa estándar activado');
        } else {
            mapa.removeLayer(capaEstandar);
            capaClara.addTo(mapa);
            capaActual = 'clara';
            mostrarToast('Mapa claro activado');
        }
    });
}

function configurarSwap() {
    const btn = document.getElementById('btnSwap');
    const origen = document.getElementById('origen');
    const destino = document.getElementById('destino');

    btn.addEventListener('click', () => {
        const temp = origen.value;
        origen.value = destino.value;
        destino.value = temp;

        btn.classList.add('spun');
        setTimeout(() => btn.classList.remove('spun'), 200);

        calcularRuta();
    });
}

function configurarEnter() {
    ['origen', 'destino'].forEach(id => {
        document.getElementById(id).addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                calcularRuta();
                cerrarTodosLosPaneles();
            }
        });
    });
}

function configurarNavegar() {
    // El parámetro "true" indica que es una navegación real del usuario
    // (a diferencia de la ruta inicial que se calcula sola al cargar la página),
    // por eso solo aquí se registra el viaje en el historial.
    document.getElementById('btnNavigate').addEventListener('click', () => calcularRuta(true));
}

/* ---------- Tarifas: se cargan desde la base de datos (las edita el admin) ---------- */
const CLAVES_TARIFA_TIPO = ['frecuente', 'estudiantil', 'adulto_mayor', 'discapacidad', 'eventual'];
const CLAVES_TARIFA_ARVI = ['arvi_civica', 'arvi_nacional', 'arvi_extranjero'];

// Llena los dos selects de Configuración con las tarifas de la BD (tarifas.php). El
// value de cada <option> es el precio, así calcularTarifaViaje() solo necesita leer
// select.value.
async function cargarTarifas() {
    const selectTipo = document.getElementById('tarifaTipo');
    const selectArvi = document.getElementById('tarifaArvi');
    if (!selectTipo || !selectArvi) return;

    try {
        const res = await fetch(API_BASE + 'tarifas.php', { credentials: 'same-origin' });
        const data = await res.json();
        if (!data.exito) throw new Error(data.mensaje || 'No se pudieron cargar las tarifas');

        const porClave = {};
        data.tarifas.forEach(t => { porClave[t.clave] = t; });

        selectTipo.innerHTML = CLAVES_TARIFA_TIPO
            .filter(clave => porClave[clave])
            .map(clave => {
                const t = porClave[clave];
                return `<option value="${t.valor}">${t.etiqueta} ($${formatearMiles(t.valor)})</option>`;
            }).join('');

        selectArvi.innerHTML = CLAVES_TARIFA_ARVI
            .filter(clave => porClave[clave])
            .map(clave => {
                const t = porClave[clave];
                return `<option value="${t.valor}">${t.etiqueta} ($${formatearMiles(t.valor)})</option>`;
            }).join('');

        // Refleja de inmediato el nuevo precio en el resumen de la ruta, si ya hay una calculada.
        const origen = document.getElementById('origen').value.trim();
        const destino = document.getElementById('destino').value.trim();
        if (origen && destino) calcularRuta();
    } catch (err) {
        console.warn('Error al cargar tarifas:', err);
    }
}

/* =========================================================
   AVISOS DEL ADMINISTRADOR (campanita en el logo)
   ========================================================= */
const AVISOS_STORAGE_KEY = 'sum_ultimo_aviso_visto';

// Campanita de avisos: consulta avisos.php al cargar y luego cada 45 segundos (polling).
// Guarda en localStorage el id del último aviso visto para contar los no leídos (badge),
// sin necesitar una tabla extra en la BD.
async function configurarAvisos() {
    const btn = document.getElementById('btnAvisos');
    const dropdown = document.getElementById('avisosDropdown');
    const btnClose = document.getElementById('avisosDropdownClose');
    const lista = document.getElementById('avisosDropdownList');
    const badge = document.getElementById('avisosBadge');
    if (!btn || !dropdown) return;

    let avisosCache = [];

    async function cargar(esActualizacionAutomatica = false) {
        const ultimoVistoAntes = Number(localStorage.getItem(AVISOS_STORAGE_KEY) || 0);
        const idsAntes = new Set(avisosCache.map(a => a.id));

        try {
            const res = await fetch(API_BASE + 'avisos.php', { credentials: 'same-origin' });
            const data = await res.json();
            avisosCache = (data.exito && data.avisos) ? data.avisos : [];

            if (!avisosCache.length) {
                lista.innerHTML = '<p class="avisos-empty">No hay avisos por ahora.</p>';
                badge.style.display = 'none';
                return;
            }

            lista.innerHTML = avisosCache.map(a => `
                <div class="aviso-item">
                    <h5>${escaparHtmlMapa(a.titulo)}</h5>
                    <p>${escaparHtmlMapa(a.mensaje)}</p>
                    <span>${formatearFechaAviso(a.creado_en)}</span>
                </div>
            `).join('');

            // Si el panel está abierto en este momento, se considera que el usuario
            // ya está viendo lo nuevo, así que se marca como leído de una vez.
            if (dropdown.classList.contains('show')) {
                const maxId = Math.max(...avisosCache.map(a => a.id));
                localStorage.setItem(AVISOS_STORAGE_KEY, String(maxId));
                badge.style.display = 'none';
            } else {
                const nuevos = avisosCache.filter(a => a.id > ultimoVistoAntes).length;
                if (nuevos > 0) {
                    badge.textContent = nuevos;
                    badge.style.display = 'flex';
                } else {
                    badge.style.display = 'none';
                }
            }

            // Si esta carga vino sola (polling, no la inicial) y trajo un aviso
            // que antes no estaba en la lista, se avisa con un toast.
            if (esActualizacionAutomatica) {
                const llegoUnoNuevo = avisosCache.some(a => !idsAntes.has(a.id));
                if (llegoUnoNuevo) mostrarToast('Nuevo aviso del administrador');
            }
        } catch (err) {
            lista.innerHTML = '<p class="avisos-empty">No se pudieron cargar los avisos.</p>';
            console.warn('Error al cargar avisos:', err);
        }
    }

    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdown.classList.toggle('show');
        if (dropdown.classList.contains('show') && avisosCache.length) {
            // Al abrir el panel se marcan todos como vistos (solo en este navegador).
            const maxId = Math.max(...avisosCache.map(a => a.id));
            localStorage.setItem(AVISOS_STORAGE_KEY, String(maxId));
            badge.style.display = 'none';
        }
    });

    if (btnClose) {
        btnClose.addEventListener('click', (e) => {
            e.stopPropagation();
            dropdown.classList.remove('show');
        });
    }

    document.addEventListener('click', (e) => {
        if (!dropdown.contains(e.target) && e.target !== btn) {
            dropdown.classList.remove('show');
        }
    });

    await cargar();

    // Revisa si hay avisos nuevos cada 45 segundos, sin que el usuario recargue la página.
    setInterval(() => cargar(true), 45000);
}

// SEGURIDAD (XSS): convierte caracteres especiales (<, >, comillas) en texto inofensivo
// antes de insertar datos en innerHTML. Evita que un nombre o un aviso con código
// malicioso se ejecute en el navegador.
function escaparHtmlMapa(texto) {
    const div = document.createElement('div');
    div.textContent = texto ?? '';
    // innerHTML no escapa comillas; se hace aquí para poder usarlo también dentro de atributos.
    return div.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function formatearFechaAviso(fechaMysql) {
    const fecha = new Date(fechaMysql.replace(' ', 'T'));
    return fecha.toLocaleString('es-CO', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}

/* =========================================================
   CUENTA SUSPENDIDA MIENTRAS EL USUARIO YA ESTÁ NAVEGANDO
   ========================================================= */
// Consulta verificar_sesion.php cada 20 segundos: si el administrador suspendió la
// cuenta, se muestra un aviso y se redirige al inicio.
function configurarVerificacionSesion() {
    async function verificar() {
        try {
            const res = await fetch(API_BASE + 'verificar_sesion.php', { credentials: 'same-origin' });
            const data = await res.json();

            // Solo actuamos cuando el servidor confirma explícitamente que ya
            // no hay sesión válida (cuenta suspendida). Un error de red no debe
            // sacar a nadie por accidente.
            if (data.exito === false && data.motivo === 'suspendida') {
                mostrarToast(data.mensaje);
                setTimeout(() => { window.location.href = '../INDEX/index.html'; }, 1800);
            }
        } catch (err) {
            console.warn('Error al verificar la sesión:', err);
        }
    }

    verificar(); // revisión inicial al cargar la página
    setInterval(verificar, 20000); // y cada 20 segundos mientras siga aquí
}

/* ---------- Recalcular precio si el usuario cambia de tarifa en Configuración ---------- */
function configurarCambioTarifa() {    ['tarifaTipo', 'tarifaArvi'].forEach(id => {
        const select = document.getElementById(id);
        if (!select) return;
        select.addEventListener('change', () => {
            const origen = document.getElementById('origen').value.trim();
            const destino = document.getElementById('destino').value.trim();
            if (origen && destino) calcularRuta();
        });
    });
}

/* =========================================================
   ACCESO DE ADMINISTRADOR (Configuración -> modal de contraseña)
   ========================================================= */

// URL a la que se redirige tras validar la contraseña correctamente.
// ADMIN/ es una carpeta hermana de MAPA/ y PHP/ dentro del proyecto.
const ADMIN_REDIRECT_URL = '../ADMIN/adminindex.html';

// Modal de contraseña de administrador. La contraseña NO se valida aquí: se envía a
// verificar_admin.php, que la compara con un hash guardado en la BD y bloquea la IP tras
// 5 intentos fallidos (15 minutos). Si es correcta, el servidor marca la sesión como
// admin y se redirige al panel.
function configurarAdminAccess() {
    const btnAbrir = document.getElementById('btnIngresarAdmin');
    const overlay = document.getElementById('adminModalOverlay');
    const btnCerrar = document.getElementById('adminModalClose');
    const form = document.getElementById('adminModalForm');
    const input = document.getElementById('adminPassword');
    const btnToggle = document.getElementById('adminPasswordToggle');
    const errorMsg = document.getElementById('adminModalError');
    const btnSubmit = document.getElementById('btnAdminSubmit');
    const btnSubmitText = document.getElementById('btnAdminSubmitText');

    if (!btnAbrir || !overlay) return;

    // Marca de tiempo hasta la que el servidor bloqueó los intentos (0 = sin bloqueo)
    let bloqueadoHasta = 0;

    function abrirModal() {
        overlay.classList.add('show');
        errorMsg.style.display = 'none';
        input.value = '';
        input.type = 'password';
        if (window.lucide) lucide.createIcons();
        setTimeout(() => input.focus(), 50);
    }

    function cerrarModal() {
        overlay.classList.remove('show');
    }

    btnAbrir.addEventListener('click', abrirModal);
    btnCerrar.addEventListener('click', cerrarModal);

    // Cerrar al hacer clic fuera de la tarjeta del modal
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) cerrarModal();
    });

    // Cerrar con la tecla Escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && overlay.classList.contains('show')) cerrarModal();
    });

    // Mostrar/ocultar la contraseña escrita
    btnToggle.addEventListener('click', () => {
        const esOculta = input.type === 'password';
        input.type = esOculta ? 'text' : 'password';
        btnToggle.innerHTML = esOculta
            ? '<i data-lucide="eye-off"></i>'
            : '<i data-lucide="eye"></i>';
        if (window.lucide) lucide.createIcons();
    });

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const clave = input.value.trim();
        errorMsg.style.display = 'none';

        if (Date.now() < bloqueadoHasta) return; // sigue bloqueado; el servidor lo volvería a rechazar

        if (!clave) {
            errorMsg.textContent = 'Ingresa la contraseña.';
            errorMsg.style.display = 'block';
            return;
        }

        btnSubmit.disabled = true;
        btnSubmitText.textContent = 'Verificando...';

        try {
            const data = await verificarPasswordAdmin(clave);
            if (data.exito) {
                window.location.href = ADMIN_REDIRECT_URL;
            } else {
                errorMsg.textContent = data.mensaje || 'Contraseña incorrecta. Intenta de nuevo.';
                errorMsg.style.display = 'block';
                input.value = '';
                if (data.bloqueado) {
                    // Se deshabilita el botón hasta que termine el bloqueo que indicó el servidor
                    bloqueadoHasta = Date.now() + (Number(data.segundos) || 0) * 1000;
                    btnSubmit.disabled = true;
                    setTimeout(() => { btnSubmit.disabled = false; }, (Number(data.segundos) || 0) * 1000);
                } else {
                    input.focus();
                }
            }
        } catch (err) {
            console.warn('Error al verificar el acceso de administrador:', err);
            errorMsg.textContent = 'No se pudo validar el acceso. Intenta más tarde.';
            errorMsg.style.display = 'block';
        } finally {
            btnSubmit.disabled = Date.now() < bloqueadoHasta;
            btnSubmitText.textContent = 'Ingresar';
        }
    });
}

// Envía la contraseña al backend para que la valide contra la cuenta
// de administrador. Devuelve la respuesta completa del servidor:
// { exito, mensaje, intentos_restantes?, bloqueado?, segundos? }.
// El endpoint nunca confirma ni expone la contraseña real.
async function verificarPasswordAdmin(password) {
    const res = await fetch(API_BASE + 'verificar_admin.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin', // envía la cookie de sesión PHP
        body: JSON.stringify({ password })
    });
    const data = await res.json();
    return data;
}

/* =========================================================
   HISTORIAL DE VIAJES (por usuario, guardado en el backend)
   ========================================================= */

// Ruta base de los PHP: todas las llamadas fetch() usan API_BASE + 'archivo.php'.
const API_BASE = '../PHP/'; // MAPA/ y PHP/ son carpetas hermanas dentro del proyecto

// Envía al backend el viaje que el usuario acaba de iniciar.
// Si la sesión expiró o hay un error de red, solo se avisa por consola:
// no debe interrumpir la experiencia de navegación en el mapa.
// Nota de diseño: el tiempo y el costo se calculan aquí, en el navegador, y el servidor
// los guarda tal cual. Una mejora futura sería recalcular el costo en el servidor usando
// la tabla de tarifas.
async function registrarViaje({ origen, destino, linea, minutos, costo }) {
    try {
        const res = await fetch(API_BASE + 'registrar_viaje.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin', // envía la cookie de sesión PHP
            body: JSON.stringify({ origen, destino, linea, minutos, costo })
        });
        const data = await res.json();
        if (!data.exito) {
            console.warn('No se pudo registrar el viaje:', data.mensaje);
        }
    } catch (err) {
        console.warn('Error de red al registrar el viaje:', err);
    }
}

// Pide al backend el historial + estadísticas del mes del usuario actual
// y actualiza la vista "Historial de viajes".
async function cargarHistorial() {
    const lista = document.getElementById('historyList');
    const vacio = document.getElementById('historyEmpty');
    if (!lista) return;

    try {
        const res = await fetch(API_BASE + 'historial.php', {
            method: 'GET',
            credentials: 'same-origin'
        });
        const data = await res.json();

        if (!data.exito) {
            lista.innerHTML = `<p class="history-empty">No se pudo cargar tu historial. Vuelve a iniciar sesión.</p>`;
            return;
        }

        // Estadísticas del mes
        const statViajes = document.getElementById('statViajesMes');
        const statTiempo = document.getElementById('statTiempoMes');
        const statCosto = document.getElementById('statCostoMes');
        if (statViajes) statViajes.textContent = data.stats.viajes_mes;
        if (statTiempo) statTiempo.textContent = `${data.stats.minutos_mes} min`;
        if (statCosto) statCosto.textContent = `$${formatearMiles(data.stats.costo_mes)} COP`;

        // Lista de viajes
        if (!data.viajes.length) {
            lista.innerHTML = '';
            if (vacio) { vacio.style.display = 'block'; lista.appendChild(vacio); }
            return;
        }

        lista.innerHTML = data.viajes.map(v => `
            <div class="history-item">
                <div class="history-icon ${colorPorLinea(v.linea)}"><i data-lucide="arrow-up-right"></i></div>
                <div class="history-info">
                    <h3>${escaparHtmlMapa(v.estacion_origen)} ➔ ${escaparHtmlMapa(v.estacion_destino)}</h3>
                    <p>${formatearFecha(v.fecha_hora)} • ${escaparHtmlMapa(v.linea)} • ${Number(v.duracion_min)} min</p>
                </div>
                <div class="history-price">
                    <span class="amount">-$${formatearMiles(v.costo)} COP</span>
                </div>
            </div>
        `).join('');

        if (window.lucide) lucide.createIcons();
    } catch (err) {
        lista.innerHTML = `<p class="history-empty">No se pudo conectar con el servidor.</p>`;
        console.warn('Error de red al cargar el historial:', err);
    }
}

function formatearMiles(numero) {
    return Number(numero).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function formatearFecha(fechaMysql) {
    const fecha = new Date(fechaMysql.replace(' ', 'T'));
    return fecha.toLocaleString('es-CO', {
        day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit'
    });
}

// Elige el color del icono en el historial según el texto de la línea usada.
function colorPorLinea(linea) {
    if (linea.includes('Metrocable') || linea.includes('Tranvía')) return 'purple';
    if (linea.includes('B')) return 'orange';
    return 'green';
}

/* =========================================================
   VISTA "USUARIO" (perfil editable de la cuenta en sesión)
   ========================================================= */

// Muestra la foto (si existe) o las iniciales de respaldo en un avatar dado.
function aplicarAvatar(imgId, fallbackId, fotoUrl, nombre) {
    const img = document.getElementById(imgId);
    const fallback = document.getElementById(fallbackId);
    if (fallback) fallback.textContent = obtenerIniciales(nombre);

    if (fotoUrl && img) {
        img.src = fotoUrl;
        img.style.display = 'block';
        if (fallback) fallback.style.display = 'none';
    } else {
        if (img) img.style.display = 'none';
        if (fallback) fallback.style.display = 'flex';
    }
}

// Pide al backend los datos de la cuenta y llena la vista "Usuario"
// (formulario editable) y el mini-perfil de la barra lateral.
async function cargarPerfil() {
    const vacio = document.getElementById('profileEmpty');

    try {
        const res = await fetch(API_BASE + 'perfil.php', {
            method: 'GET',
            credentials: 'same-origin'
        });
        const data = await res.json();

        if (!data.exito) {
            if (vacio) vacio.style.display = 'block';
            return;
        }
        if (vacio) vacio.style.display = 'none';

        const u = data.usuario;

        // Sidebar (mini-perfil)
        const nombreSidebar = document.getElementById('sidebarProfileName');
        if (nombreSidebar) nombreSidebar.textContent = u.nombre;
        aplicarAvatar('sidebarAvatarImg', 'sidebarAvatarFallback', u.foto_url, u.nombre);

        // Formulario de la vista "Usuario"
        const campoNombre = document.getElementById('profileNombre');
        const campoUsuario = document.getElementById('profileUsuarioTxt');
        const campoEmail = document.getElementById('profileEmail');
        if (campoNombre) campoNombre.value = u.nombre || '';
        if (campoUsuario) campoUsuario.value = u.usuario || '';
        if (campoEmail) campoEmail.value = u.email || '';
        aplicarAvatar('profileAvatarImg', 'profileAvatarFallback', u.foto_url, u.nombre);
    } catch (err) {
        if (vacio) { vacio.style.display = 'block'; vacio.textContent = 'No se pudo conectar con el servidor.'; }
        console.warn('Error de red al cargar el perfil:', err);
    }
}

// Toma hasta las dos primeras iniciales del nombre completo (ej. "Juan Pérez" -> "JP")
// para mostrarlas como foto de perfil provisional mientras no haya una foto real.
function obtenerIniciales(nombreCompleto) {
    const partes = (nombreCompleto || '').trim().split(/\s+/).filter(Boolean);
    if (!partes.length) return '?';
    const primera = partes[0][0] || '';
    const segunda = partes.length > 1 ? (partes[1][0] || '') : '';
    return (primera + segunda).toUpperCase();
}

/* ---------- Vista "Usuario": vista previa de la foto + guardar cambios ---------- */
function configurarUsuario() {
    const inputFoto = document.getElementById('inputFoto');
    if (inputFoto) {
        inputFoto.addEventListener('change', () => {
            const archivo = inputFoto.files && inputFoto.files[0];
            if (!archivo) return;

            if (archivo.size > 2 * 1024 * 1024) {
                mostrarToast('La imagen debe pesar máximo 2MB');
                inputFoto.value = '';
                return;
            }

            // Vista previa inmediata mientras se sube (el guardado real ocurre al pulsar "Guardar cambios")
            const lector = new FileReader();
            lector.onload = (e) => {
                const img = document.getElementById('profileAvatarImg');
                const fallback = document.getElementById('profileAvatarFallback');
                if (img) { img.src = e.target.result; img.style.display = 'block'; }
                if (fallback) fallback.style.display = 'none';
            };
            lector.readAsDataURL(archivo);
        });
    }

    const btnGuardar = document.getElementById('btnGuardarPerfil');
    if (btnGuardar) {
        btnGuardar.addEventListener('click', () => guardarPerfil());
    }
}

// Envía los datos del formulario (y la foto, si se eligió una) al backend
// para que queden guardados de verdad en la base de datos.
async function guardarPerfil() {
    const btnGuardar = document.getElementById('btnGuardarPerfil');
    const formData = new FormData();
    formData.append('nombre', document.getElementById('profileNombre').value.trim());
    formData.append('usuario', document.getElementById('profileUsuarioTxt').value.trim());
    formData.append('email', document.getElementById('profileEmail').value.trim());

    const inputFoto = document.getElementById('inputFoto');
    if (inputFoto && inputFoto.files && inputFoto.files[0]) {
        formData.append('foto', inputFoto.files[0]);
    }

    btnGuardar.disabled = true;
    try {
        const res = await fetch(API_BASE + 'actualizar_perfil.php', {
            method: 'POST',
            credentials: 'same-origin',
            body: formData
        });
        const data = await res.json();

        if (!data.exito) {
            mostrarToast(data.mensaje || 'No se pudieron guardar los cambios');
            return;
        }

        mostrarToast('Datos de usuario guardados');
        if (inputFoto) inputFoto.value = '';

        // Refleja de inmediato el nuevo nombre/foto en el mini-perfil del sidebar
        const u = data.usuario;
        const nombreSidebar = document.getElementById('sidebarProfileName');
        if (nombreSidebar) nombreSidebar.textContent = u.nombre;
        aplicarAvatar('sidebarAvatarImg', 'sidebarAvatarFallback', u.foto_url, u.nombre);
        aplicarAvatar('profileAvatarImg', 'profileAvatarFallback', u.foto_url, u.nombre);
    } catch (err) {
        mostrarToast('Error de red al guardar los cambios');
        console.warn('Error de red al guardar el perfil:', err);
    } finally {
        btnGuardar.disabled = false;
    }
}

/* =========================================================
   Buscador de estaciones: panel agrupado por línea, con la
   dirección de cada estación visible debajo del nombre.
   ========================================================= */

function cerrarTodosLosPaneles() {
    document.querySelectorAll('.station-dropdown').forEach(p => p.classList.remove('open'));
}

// Construye el desplegable de estaciones: recorre las líneas en ORDEN_LINEAS, filtra por
// lo escrito (sin tildes ni mayúsculas) y crea un grupo con el color de cada línea. Al
// hacer clic en una opción, la escribe en el campo y recalcula la ruta.
function renderizarOpcionesEstacion(panel, inputId, filtro) {
    panel.innerHTML = '';
    const q = normalizarTexto(filtro || '');
    let huboResultados = false;

    ORDEN_LINEAS.forEach(clave => {
        const linea = LINEAS[clave];
        if (!linea) return;

        const estacionesFiltradas = linea.estaciones.filter(e => !q || normalizarTexto(e.nombre).includes(q));
        if (!estacionesFiltradas.length) return;
        huboResultados = true;

        const grupo = document.createElement('div');
        grupo.className = 'station-group';

        const titulo = document.createElement('div');
        titulo.className = 'station-group-label';
        titulo.innerHTML = `<span class="station-group-dot" style="background:${linea.color};"></span>${escaparHtmlMapa(ETIQUETAS_LINEA[clave] || clave.toUpperCase())}`;
        grupo.appendChild(titulo);

        estacionesFiltradas.forEach(estacion => {
            const opcion = document.createElement('button');
            opcion.type = 'button';
            opcion.className = 'station-option';
            opcion.innerHTML = `<span class="station-name">${escaparHtmlMapa(estacion.nombre)}</span>`
                + `<span class="station-address">${escaparHtmlMapa(estacion.dir || 'Dirección no disponible')}</span>`;
            opcion.addEventListener('click', () => {
                const input = document.getElementById(inputId);
                input.value = estacion.nombre;
                cerrarTodosLosPaneles();
                calcularRuta();
            });
            grupo.appendChild(opcion);
        });

        panel.appendChild(grupo);
    });

    if (!huboResultados) {
        const vacio = document.createElement('div');
        vacio.className = 'station-empty';
        vacio.textContent = 'No se encontraron estaciones con ese nombre';
        panel.appendChild(vacio);
    }
}

function configurarAutocompletado() {
    ['origen', 'destino'].forEach(id => {
        const input = document.getElementById(id);
        if (!input) return;

        // Ya no se usa el datalist nativo del navegador: el buscador propio
        // agrupa por línea y muestra la dirección de cada estación.
        input.removeAttribute('list');
        input.setAttribute('autocomplete', 'off');
        input.setAttribute('placeholder', 'Escribe el nombre de una estación');

        const wrap = input.closest('.route-input-wrap');
        if (!wrap) return;

        const panel = document.createElement('div');
        panel.className = 'station-dropdown';
        panel.id = 'dropdown-' + id;
        wrap.appendChild(panel);

        input.addEventListener('focus', () => {
            renderizarOpcionesEstacion(panel, id, input.value);
            cerrarTodosLosPaneles();
            panel.classList.add('open');
        });

        input.addEventListener('input', () => {
            renderizarOpcionesEstacion(panel, id, input.value);
            panel.classList.add('open');
        });

        // Botón/flecha para expandir y ver todas las estaciones agrupadas
        // por línea, incluso si ya hay texto escrito en el campo.
        const toggleBtn = document.querySelector(`.station-dropdown-toggle[data-for="${id}"]`);
        if (toggleBtn) {
            toggleBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                const yaEstabaAbierto = panel.classList.contains('open');
                cerrarTodosLosPaneles();
                if (!yaEstabaAbierto) {
                    renderizarOpcionesEstacion(panel, id, '');
                    panel.classList.add('open');
                    toggleBtn.classList.add('spun');
                    input.focus();
                } else {
                    toggleBtn.classList.remove('spun');
                }
            });
        }
    });

    // Cerrar cualquier panel abierto al hacer clic fuera del campo de ruta
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.route-input-wrap')) {
            cerrarTodosLosPaneles();
            document.querySelectorAll('.station-dropdown-toggle').forEach(b => b.classList.remove('spun'));
        }
    });
}

/* ---------- Búsqueda de estaciones ---------- */
// Quita tildes y pasa a minúsculas para que 'niquia' encuentre 'Niquía'.
function normalizarTexto(txt) {
    return txt.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
}

// Busca con tres niveles de coincidencia: nombre exacto, que empiece por el texto, o que
// lo contenga.
function buscarEstacion(texto) {
    const q = normalizarTexto(texto);
    if (!q) return null;
    const candidatas = listaEstacionesUnicas();

    return candidatas.find(e => normalizarTexto(e.nombre) === q)
        || candidatas.find(e => normalizarTexto(e.nombre).startsWith(q))
        || candidatas.find(e => normalizarTexto(e.nombre).includes(q))
        || null;
}

/* ---------- Grafo de la red y cálculo de ruta (BFS) ---------- */
// El grafo conecta estaciones consecutivas de cada línea. Cuando dos
// líneas comparten el nombre de una estación (ej. "San Antonio" en A,
// B y Tranvía), esa estación funciona automáticamente como transbordo,
// sin necesidad de reglas especiales por caso.
const GRAFO = new Map();
function agregarArista(nombreA, nombreB, lineaKey) {
    if (!GRAFO.has(nombreA)) GRAFO.set(nombreA, []);
    GRAFO.get(nombreA).push({ hacia: nombreB, linea: lineaKey });
}
function construirGrafo() {
    GRAFO.clear();
    Object.entries(LINEAS).forEach(([clave, linea]) => {
        const est = linea.estaciones;
        for (let i = 0; i < est.length - 1; i++) {
            agregarArista(est[i].nombre, est[i + 1].nombre, clave);
            agregarArista(est[i + 1].nombre, est[i].nombre, clave);
        }
    });
}
construirGrafo();

// BFS (búsqueda en anchura): explora la red por niveles desde el origen y devuelve el
// camino con MENOS PARADAS hasta el destino (no necesariamente el de menor tiempo).
// 'cola' guarda lo pendiente por visitar y 'visitados' evita ciclos. Cada elemento lleva
// el camino recorrido y la línea usada en cada tramo.
function encontrarRutaOptima(origenNombre, destinoNombre) {
    if (origenNombre === destinoNombre) return null;

    const visitados = new Set([origenNombre]);
    const cola = [{ nombre: origenNombre, camino: [origenNombre], lineas: [] }];

    while (cola.length) {
        const actual = cola.shift();
        if (actual.nombre === destinoNombre) return actual;

        const vecinos = GRAFO.get(actual.nombre) || [];
        for (const v of vecinos) {
            if (!visitados.has(v.hacia)) {
                visitados.add(v.hacia);
                cola.push({
                    nombre: v.hacia,
                    camino: [...actual.camino, v.hacia],
                    lineas: [...actual.lineas, v.linea]
                });
            }
        }
    }
    return null; // no hay conexión en la red
}

// Hay un transbordo cada vez que cambia la línea entre dos tramos consecutivos.
function contarTransbordos(lineas) {
    let cambios = 0;
    for (let i = 1; i < lineas.length; i++) {
        if (lineas[i] !== lineas[i - 1]) cambios++;
    }
    return cambios;
}

/* ---------- Construcción de segmentos por línea (para las indicaciones) ---------- */
// Agrupa el camino estación-a-estación en tramos continuos que usan la
// misma línea, para poder anunciar "toma la Línea X" una sola vez por
// tramo, en lugar de estación por estación.
function construirSegmentos(camino, lineas) {
    const segmentos = [];
    let inicio = 0;
    for (let i = 1; i < lineas.length; i++) {
        if (lineas[i] !== lineas[i - 1]) {
            segmentos.push({ linea: lineas[i - 1], desde: camino[inicio], hasta: camino[i] });
            inicio = i;
        }
    }
    segmentos.push({ linea: lineas[lineas.length - 1], desde: camino[inicio], hasta: camino[camino.length - 1] });
    return segmentos;
}

// Determina el destino/terminal hacia el que avanza un tramo (p. ej.
// "dirección Niquía"), comparando el orden de las estaciones dentro del
// arreglo oficial de esa línea.
function direccionDelTramo(claveLinea, estacionDesde, estacionSiguiente) {
    const estaciones = LINEAS[claveLinea].estaciones;
    const idxDesde = estaciones.findIndex(e => e.nombre === estacionDesde);
    const idxSig = estaciones.findIndex(e => e.nombre === estacionSiguiente);
    if (idxDesde === -1 || idxSig === -1) return estaciones[estaciones.length - 1].nombre;
    return idxSig > idxDesde ? estaciones[estaciones.length - 1].nombre : estaciones[0].nombre;
}

/* ---------- Render de las indicaciones paso a paso (panel derecho) ---------- */
function ocultarIndicaciones() {
    const placeholder = document.getElementById('directionsPlaceholder');
    const lista = document.getElementById('directionsList');
    if (placeholder) placeholder.style.display = 'flex';
    if (lista) { lista.classList.remove('show'); lista.innerHTML = ''; }
}

// Arma la lista de pasos: partida → (toma la línea X → transbordo) → llegada. Cada paso
// es clicable y centra el mapa en esa estación.
function renderizarIndicaciones(resultado, estacionOrigen, estacionDestino, coordsPorNombre) {
    const placeholder = document.getElementById('directionsPlaceholder');
    const lista = document.getElementById('directionsList');
    if (!lista) return;

    const segmentos = construirSegmentos(resultado.camino, resultado.lineas);
    const pasos = [];

    // Paso 1: punto de partida
    pasos.push({
        icono: 'map-pin',
        color: '#008037',
        titulo: 'Punto de partida',
        texto: `Comienza en la estación <b>${escaparHtmlMapa(estacionOrigen.nombre)}</b>.`,
        estacion: estacionOrigen.nombre
    });

    segmentos.forEach((seg, idx) => {
        const siguienteEstacion = resultado.camino[resultado.camino.indexOf(seg.desde) + 1] || seg.hasta;
        const info = infoDeLinea(seg.linea);
        const direccion = direccionDelTramo(seg.linea, seg.desde, siguienteEstacion);

        pasos.push({
            icono: 'navigation',
            color: info.color,
            titulo: `Toma la ${escaparHtmlMapa(info.etiqueta)}`,
            texto: `Desde <b>${escaparHtmlMapa(seg.desde)}</b>, dirección hacia <b>${escaparHtmlMapa(direccion)}</b>.`,
            estacion: seg.desde
        });

        const esUltimoSegmento = idx === segmentos.length - 1;
        if (!esUltimoSegmento) {
            pasos.push({
                icono: 'repeat',
                color: '#64748b',
                titulo: 'Haz transbordo',
                texto: `Baja en <b>${escaparHtmlMapa(seg.hasta)}</b> y cambia de línea.`,
                estacion: seg.hasta
            });
        }
    });

    // Último paso: destino final
    pasos.push({
        icono: 'flag',
        color: '#e0442f',
        titulo: '¡Has llegado!',
        texto: `Baja en <b>${escaparHtmlMapa(estacionDestino.nombre)}</b>. Ese es tu destino.`,
        estacion: estacionDestino.nombre
    });

    lista.innerHTML = pasos.map(paso => `
        <li class="direction-step" data-estacion="${escaparHtmlMapa(paso.estacion)}">
            <span class="direction-step-icon" style="background:${paso.color};">
                <i data-lucide="${paso.icono}"></i>
            </span>
            <div class="direction-step-body">
                <p class="direction-step-title">${paso.titulo}</p>
                <p class="direction-step-text">${paso.texto}</p>
            </div>
        </li>
    `).join('');

    if (placeholder) placeholder.style.display = 'none';
    lista.classList.add('show');
    if (window.lucide) lucide.createIcons();

    // Interactividad: al hacer clic en un paso, el mapa se centra en esa estación
    lista.querySelectorAll('.direction-step').forEach(item => {
        item.addEventListener('click', () => {
            const nombreEstacion = item.getAttribute('data-estacion');
            const est = coordsPorNombre.get(nombreEstacion);
            if (!est || !mapa) return;
            mapa.setView([est.lat, est.lon], 16, { animate: true });
            resaltarEstacionTemporal(est.lat, est.lon);
        });
    });
}

// Muestra un pulso temporal sobre la estación seleccionada en un paso
let marcadorResaltado = null;
function resaltarEstacionTemporal(lat, lon) {
    if (marcadorResaltado) mapa.removeLayer(marcadorResaltado);
    marcadorResaltado = L.marker([lat, lon], {
        icon: L.divIcon({
            className: '',
            html: '<span class="geo-marker"></span>',
            iconSize: [16, 16],
            iconAnchor: [8, 8]
        })
    }).addTo(mapa);
    setTimeout(() => {
        if (marcadorResaltado) { mapa.removeLayer(marcadorResaltado); marcadorResaltado = null; }
    }, 2500);
}

// Crea o mueve el marcador de origen (punto verde) o de destino (pin rojo).
function colocarMarcador(tipo, lat, lon) {
    if (tipo === 'origen') {
        if (marcadorOrigen) { marcadorOrigen.setLatLng([lat, lon]); return; }
        marcadorOrigen = L.marker([lat, lon], {
            icon: L.divIcon({
                className: '',
                html: '<span class="map-pin-dot"></span>',
                iconSize: [16, 16],
                iconAnchor: [8, 8]
            })
        }).addTo(mapa);
    } else {
        const svgPin = '<svg viewBox="0 0 24 24" width="30" height="30" fill="#e0442f" stroke="#fff" stroke-width="1.3">'
            + '<path d="M12 2C7.6 2 4 5.6 4 10c0 5.4 6.8 11.1 7.1 11.4.5.4 1.2.4 1.7 0C13.2 21.1 20 15.4 20 10c0-4.4-3.6-8-8-8zm0 11a3 3 0 110-6 3 3 0 010 6z"/></svg>';
        if (marcadorDestino) { marcadorDestino.setLatLng([lat, lon]); return; }
        marcadorDestino = L.marker([lat, lon], {
            icon: L.divIcon({
                className: '',
                html: svgPin,
                iconSize: [30, 30],
                iconAnchor: [15, 29]
            })
        }).addTo(mapa);
    }
}

/* ---------- Cálculo de tarifa según el/los tipo(s) de línea usados ---------- */
// El Metro, Metrocable (K/H/J), Tranvía y Metroplús forman una sola red con
// tarifa integrada (se paga una vez, sin importar transbordos entre ellos).
// El Metrocable Arví (Línea L) tiene un esquema de precios independiente:
// si el viaje entra a Arví, esa parte se cobra aparte con la tarifa
// seleccionada en Configuración > "Tarifas Metrocable Arví".
function calcularTarifaViaje(lineasUsadas) {
    const usaArvi = lineasUsadas.includes('l');
    const usaRedIntegrada = lineasUsadas.some(l => l !== 'l');

    const selectTipo = document.getElementById('tarifaTipo');
    const selectArvi = document.getElementById('tarifaArvi');

    const tarifaIntegrada = selectTipo ? Number(selectTipo.value) : 3820;
    const tarifaArvi = selectArvi ? Number(selectArvi.value) : 3900;

    let total = 0;
    if (usaRedIntegrada) total += tarifaIntegrada;
    if (usaArvi) total += tarifaArvi;

    return { total, usaArvi, usaRedIntegrada };
}

// FUNCIÓN CENTRAL. Pasos: 1) valida los campos, 2) busca las estaciones, 3) calcula la
// ruta con BFS, 4) dibuja marcadores y línea, 5) estima tiempo y costo, 6) muestra las
// indicaciones y 7) solo si el usuario pulsó 'Iniciar Navegación' (registrarViajeReal =
// true) guarda el viaje en la BD. También se llama al cargar y al cambiar origen,
// destino o tarifa, pero en silencio.
async function calcularRuta(registrarViajeReal = false) {
    const campoOrigen = document.getElementById('origen');
    const campoDestino = document.getElementById('destino');
    const origenTexto = campoOrigen.value.trim();
    const destinoTexto = campoDestino.value.trim();
    const btnNavigate = document.getElementById('btnNavigate');
    // Solo se muestra modal cuando el usuario pulsa "Iniciar Navegación"; los cálculos automáticos son silenciosos.
    const avisar = (...args) => { if (registrarViajeReal) mostrarToast(...args); };

    if (!origenTexto || !destinoTexto) {
        avisar('Ingresa una estación de origen y una de destino');
        ocultarIndicaciones();
        return;
    }

    btnNavigate.disabled = true;

    const estacionOrigen = buscarEstacion(origenTexto);
    const estacionDestino = buscarEstacion(destinoTexto);

    if (!estacionOrigen) {
        avisar(`"${origenTexto}" no es una estación del sistema`);
        btnNavigate.disabled = false;
        ocultarIndicaciones();
        return;
    }
    if (!estacionDestino) {
        avisar(`"${destinoTexto}" no es una estación del sistema`);
        btnNavigate.disabled = false;
        ocultarIndicaciones();
        return;
    }

    const resultado = encontrarRutaOptima(estacionOrigen.nombre, estacionDestino.nombre);
    if (!resultado || resultado.camino.length < 2) {
        avisar('No hay una ruta directa entre esas estaciones');
        btnNavigate.disabled = false;
        ocultarIndicaciones();
        return;
    }

    const coordsPorNombre = new Map(listaEstacionesUnicas().map(e => [e.nombre, e]));
    const tramo = resultado.camino.map(nombre => coordsPorNombre.get(nombre));

    colocarMarcador('origen', estacionOrigen.lat, estacionOrigen.lon);
    colocarMarcador('destino', estacionDestino.lat, estacionDestino.lon);

    if (lineaRuta) mapa.removeLayer(lineaRuta);
    lineaRuta = L.polyline(tramo.map(e => [e.lat, e.lon]), {
        color: '#008037',
        weight: 5,
        opacity: 0.9,
        dashArray: '1 12',
        lineCap: 'round'
    }).addTo(mapa);

    const transbordos = contarTransbordos(resultado.lineas);
    const numTramos = tramo.length - 1;
    // Estimación del tiempo: 2 minutos por tramo entre estaciones + 4 minutos por cada
    // transbordo.
    const minutos = Math.max(1, numTramos * 2 + transbordos * 4);
    document.getElementById('summaryTime').textContent = minutos;
    document.getElementById('summaryBar').style.width = Math.min(100, minutos * 4) + '%';

    const { total: costoViaje, usaArvi } = calcularTarifaViaje(resultado.lineas);
    document.getElementById('summaryCost').textContent = formatearMiles(costoViaje);

    const limites = L.latLngBounds(tramo.map(e => [e.lat, e.lon]));
    mapa.fitBounds(limites, { padding: [90, 90] });

    const sufijoTransbordo = transbordos > 0 ? ` (${transbordos} transbordo${transbordos > 1 ? 's' : ''})` : '';
    const sufijoArvi = usaArvi ? ' • incluye tarifa especial Metrocable Arví' : '';
    if (registrarViajeReal) {
        mostrarToast(`${estacionOrigen.nombre} ➔ ${estacionDestino.nombre}${sufijoTransbordo}`, 'exito', '¡Su viaje ha iniciado!');
    }
    renderizarIndicaciones(resultado, estacionOrigen, estacionDestino, coordsPorNombre);
    btnNavigate.disabled = false;

    // Solo se guarda en el historial cuando el usuario pulsa "Iniciar Navegación",
    // no cuando la ruta inicial se calcula sola al cargar la página.
    if (registrarViajeReal) {
        const lineasUsadas = [...new Set(resultado.lineas.map(l => infoDeLinea(l).etiqueta))].join(' + ');
        registrarViaje({
            origen: estacionOrigen.nombre,
            destino: estacionDestino.nombre,
            linea: lineasUsadas,
            minutos,
            costo: costoViaje
        });
    }
}

/* ---------- Toast (modal grande y momentáneo, centrado en pantalla) ---------- */
let toastTimer = null;
const TOAST_ICONOS = {
    exito: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 13l4 4L19 7"/></svg>',
    error: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 8v5M12 16.5v.5"/><circle cx="12" cy="12" r="9"/></svg>',
    info:  '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 11v6M12 7.5v.5"/><circle cx="12" cy="12" r="9"/></svg>'
};

// Si no se indica el tipo (error, info o éxito), se deduce del texto del mensaje con
// expresiones regulares.
function mostrarToast(mensaje, tipo, titulo) {
    const toast = document.getElementById('toast');
    if (!toast) return;
    if (!tipo) {
        tipo = /no se pudo|error|no es una|no hay|m\u00e1ximo|no soportada|ingresa|escribe|marca|necesita/i.test(mensaje) ? 'error'
             : /obteniendo|activado/i.test(mensaje) ? 'info' : 'exito';
    }
    toast.className = 'toast toast-' + tipo;
    toast.innerHTML = '<div class="toast-box" role="status" aria-live="polite">' +
        '<span class="toast-icon">' + TOAST_ICONOS[tipo] + '</span>' +
        (titulo ? '<strong class="toast-title"></strong>' : '') +
        '<p class="toast-text"></p></div>';
    if (titulo) toast.querySelector('.toast-title').textContent = titulo;
    toast.querySelector('.toast-text').textContent = mensaje;
    void toast.offsetWidth; // reinicia la animación si ya había uno visible
    toast.classList.add('show');

    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), tipo === 'error' ? 2200 : 1600);
}
